import { db } from "@/db";
import { users, announcements, settings, gmailSubmissions, withdrawals } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, makeSalt } from "@/lib/auth";
import { generateReferralCode } from "@/lib/utils";

async function main() {
  // Check if admin exists
  const adminCheck = await db
    .select()
    .from(users)
    .where(eq(users.role, "admin"))
    .limit(1);

  if (adminCheck[0]) {
    console.log("Already seeded, skipping.");
    return;
  }

  console.log("Seeding database...");

  // Admin
  const salt = makeSalt();
  const adminResult = await db
    .insert(users)
    .values({
      name: "Admin Zero99",
      email: "admin@zero99.com",
      password: hashPassword("admin123", salt),
      salt,
      referralCode: "ADMIN99",
      balance: 0,
      role: "admin",
    })
    .returning();
  const admin = adminResult[0];

  // Settings
  const defaultSettings: Array<[string, string]> = [
    ["siteName", "S3L GMAIL ZERO99"],
    ["pricePerGmail", "4700"],
    ["minWithdrawal", "25000"],
    ["referralBonus", "500"],
    ["withdrawalFee", "1500"],
  ];
  for (const [key, value] of defaultSettings) {
    await db
      .insert(settings)
      .values({ key, value })
      .onConflictDoUpdate({ target: settings.key, set: { value } });
  }

  // Demo users
  const demoUsers = [
    { name: "Budi Santoso", email: "budi@cuan.com", pw: "budi123", ref: null as string | null },
    { name: "Siti Wijaya", email: "siti@cuan.com", pw: "siti123", ref: "ADMIN99" },
    { name: "Andi Pratama", email: "andi@cuan.com", pw: "andi123", ref: "ADMIN99" },
    { name: "Dewi Lestari", email: "dewi@cuan.com", pw: "dewi123", ref: null as string | null },
    { name: "Rizky Ramadhan", email: "rizky@cuan.com", pw: "rizky123", ref: "ADMIN99" },
  ];

  const createdUsers = [];
  for (const u of demoUsers) {
    const s = makeSalt();
    const result = await db
      .insert(users)
      .values({
        name: u.name,
        email: u.email,
        password: hashPassword(u.pw, s),
        salt: s,
        referralCode: generateReferralCode(),
        referredBy: u.ref,
        balance: 0,
        role: "user",
      })
      .returning();
    createdUsers.push(result[0]);
  }

  // Demo submissions
  const demoGmails = [
    { userId: createdUsers[0].id, email: "budi.santoso123@gmail.com", pw: "Gmail@123", status: "APPROVED", phone: "081234567890" },
    { userId: createdUsers[0].id, email: "budi.wijaya456@gmail.com", pw: "Gmail@456", status: "APPROVED", phone: null },
    { userId: createdUsers[0].id, email: "budi.pratama789@gmail.com", pw: "Gmail@789", status: "PENDING", phone: "081234567890" },
    { userId: createdUsers[1].id, email: "siti.mulyadi123@gmail.com", pw: "Siti@123", status: "APPROVED", phone: null },
    { userId: createdUsers[1].id, email: "siti.kurnia456@gmail.com", pw: "Siti@456", status: "PENDING", phone: "085678901234" },
    { userId: createdUsers[2].id, email: "andi.setiawan123@gmail.com", pw: "Andi@123", status: "APPROVED", phone: null },
    { userId: createdUsers[2].id, email: "andi.puspita456@gmail.com", pw: "Andi@456", status: "REJECTED", phone: null, note: "Gmail tidak aktif" },
    { userId: createdUsers[3].id, email: "dewi.ramadhan123@gmail.com", pw: "Dewi@123", status: "APPROVED", phone: "087890123456" },
    { userId: createdUsers[4].id, email: "rizky.fitriani123@gmail.com", pw: "Rizky@123", status: "PENDING", phone: null },
  ];

  for (const g of demoGmails) {
    await db.insert(gmailSubmissions).values({
      userId: g.userId,
      accountEmail: g.email,
      accountPassword: g.pw,
      recoveryPhone: g.phone,
      status: g.status,
      price: 4700,
      adminNote: (g as any).note ?? null,
      reviewedAt: g.status !== "PENDING" ? new Date() : null,
    });
  }

  // Update balances based on approved submissions
  const approved = await db
    .select({ userId: gmailSubmissions.userId, price: gmailSubmissions.price })
    .from(gmailSubmissions)
    .where(eq(gmailSubmissions.status, "APPROVED"));

  const balanceMap = new Map<number, number>();
  for (const a of approved) {
    balanceMap.set(a.userId, (balanceMap.get(a.userId) ?? 0) + a.price);
  }
  for (const [userId, bal] of balanceMap) {
    await db
      .update(users)
      .set({ balance: bal, totalEarned: bal })
      .where(eq(users.id, userId));
  }

  // Demo withdrawal
  await db.insert(withdrawals).values({
    userId: createdUsers[0].id,
    method: "DANA",
    accountName: "Budi Santoso",
    accountNumber: "081234567890",
    amount: 9400,
    fee: 1500,
    status: "APPROVED",
    reviewedAt: new Date(),
  });

  // Announcements
  await db.insert(announcements).values([
    {
      title: "Selamat datang di S3L GMAIL ZERO99!",
      content:
        "Platform setoran Gmail resmi telah dibuka. Setiap Gmail yang disetorkan dan disetujui akan langsung ditambahkan ke saldo Anda. Penarikan diproses 1-2 menit.",
    },
    {
      title: "Bonus Referral Rp500 / Gmail",
      content:
        "Ajak teman mendaftar menggunakan kode referral Anda. Setiap Gmail teman Anda yang disetujui, Anda mendapat bonus Rp500 otomatis.",
    },
    {
      title: "Penting: Gunakan Gmail Aktif",
      content:
        "Pastikan akun Gmail yang disetorkan aktif dan bisa dibuka. Gmail yang tidak valid akan ditolak oleh tim admin.",
    },
  ]);

  console.log("Seed complete!");
  console.log("Admin: admin@zero99.com / admin123");
  console.log("Demo users: budi@cuan.com / budi123, etc.");
}

main().catch((e) => {
  console.error("Seed failed:", e);
  process.exit(1);
});
