"use client";

import { useEffect, useState } from "react";
import {
  Users,
  Loader2,
  Pencil,
  Check,
  X,
  ShieldCheck,
} from "lucide-react";
import {
  Card,
  CardHeader,
  Badge,
  EmptyState,
  useToast,
} from "@/components/ui";
import { formatIDR, formatNumber, formatDateTime } from "@/lib/utils";

interface UserRow {
  id: number;
  name: string;
  email: string;
  referralCode: string;
  referredBy: string | null;
  balance: number;
  totalEarned: number;
  role: string;
  createdAt: string;
  submissionCount: number;
}

export default function AdminPenggunaPage() {
  const { toast } = useToast();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<number | null>(null);
  const [editBalance, setEditBalance] = useState("");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const res = await fetch("/api/admin/users");
      const data = await res.json();
      setUsers(data.users ?? []);
    } catch {
      toast("Gagal memuat data", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const startEdit = (u: UserRow) => {
    setEditing(u.id);
    setEditBalance(String(u.balance));
  };

  const save = async (id: number) => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, balance: Number(editBalance) }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal menyimpan", "error");
        return;
      }
      toast("Saldo diperbarui");
      setEditing(null);
      load();
    } catch {
      toast("Terjadi kesalahan", "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Pengguna
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Kelola member dan saldo mereka.
        </p>
      </div>

      <Card>
        <CardHeader
          title="Semua Pengguna"
          subtitle={`${users.length} member`}
        />
        {loading ? (
          <div className="flex items-center justify-center py-14">
            <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
          </div>
        ) : users.length === 0 ? (
          <EmptyState
            icon={<Users className="h-6 w-6" />}
            title="Belum ada pengguna"
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Pengguna
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Referral
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Saldo
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Total Cuan
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Setoran
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Bergabung
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Aksi
                  </th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr
                    key={u.id}
                    className="border-b border-slate-800/50 transition hover:bg-slate-800/30"
                  >
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-medium text-slate-200">
                          {u.name}
                        </p>
                        {u.role === "admin" && (
                          <Badge variant="rose">
                            <ShieldCheck className="h-3 w-3" />
                            Admin
                          </Badge>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        {u.email}
                      </p>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <Badge variant="default">{u.referralCode}</Badge>
                      {u.referredBy && (
                        <p className="mt-1 text-[11px] text-slate-500">
                          via {u.referredBy}
                        </p>
                      )}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      {editing === u.id ? (
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            value={editBalance}
                            onChange={(e) => setEditBalance(e.target.value)}
                            className="h-8 w-28 rounded-lg border border-slate-700 bg-slate-900 px-2 text-xs text-slate-100 outline-none focus:border-rose-500/60"
                          />
                          <button
                            onClick={() => save(u.id)}
                            disabled={saving}
                            className="rounded-lg bg-emerald-500/15 p-1.5 text-emerald-400 hover:bg-emerald-500/25 cursor-pointer"
                          >
                            {saving ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Check className="h-3.5 w-3.5" />
                            )}
                          </button>
                          <button
                            onClick={() => setEditing(null)}
                            className="rounded-lg bg-slate-800 p-1.5 text-slate-400 hover:bg-slate-700 cursor-pointer"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span className="font-semibold text-emerald-400">
                          {formatIDR(u.balance)}
                        </span>
                      )}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5 text-xs text-slate-300">
                      {formatIDR(u.totalEarned)}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5 text-xs text-slate-300">
                      {formatNumber(Number(u.submissionCount))}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5 text-xs text-slate-400">
                      {formatDateTime(u.createdAt)}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      {editing !== u.id && (
                        <button
                          onClick={() => startEdit(u)}
                          className="rounded-lg border border-slate-700 p-2 text-slate-400 transition hover:border-rose-500/40 hover:text-rose-400 cursor-pointer"
                          title="Edit saldo"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
