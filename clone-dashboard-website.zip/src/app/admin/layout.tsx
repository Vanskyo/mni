import type { ReactNode } from "react";
import { requireAdmin } from "@/lib/auth";
import { AdminSidebar } from "@/components/Sidebar";
import { ToastProvider } from "@/components/ui";

export default async function AdminLayout({
  children,
}: {
  children: ReactNode;
}) {
  const user = await requireAdmin();

  return (
    <ToastProvider>
      <div className="min-h-screen bg-slate-950">
        <AdminSidebar
          user={{
            name: user.name,
            email: user.email,
            balance: user.balance,
            role: user.role,
          }}
        />
        <main className="lg:pl-64">
          <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
            {children}
          </div>
        </main>
      </div>
    </ToastProvider>
  );
}
