"use client";

import { useEffect, useState } from "react";
import {
  Inbox,
  CheckCircle2,
  XCircle,
  Loader2,
  Copy,
  Eye,
  EyeOff,
} from "lucide-react";
import {
  Card,
  CardHeader,
  StatusBadge,
  EmptyState,
  Badge,
  Button,
  useToast,
  CopyButton,
} from "@/components/ui";
import { formatIDR, formatDateTime } from "@/lib/utils";

interface Submission {
  id: number;
  accountEmail: string;
  accountPassword: string;
  recoveryPhone: string | null;
  status: string;
  price: number;
  adminNote: string | null;
  createdAt: string;
  userName: string;
  userEmail: string;
}

const FILTERS = [
  { key: "ALL", label: "Semua" },
  { key: "PENDING", label: "Pending" },
  { key: "APPROVED", label: "Disetujui" },
  { key: "REJECTED", label: "Ditolak" },
];

export default function AdminSetoranPage() {
  const { toast } = useToast();
  const [list, setList] = useState<Submission[]>([]);
  const [filter, setFilter] = useState("ALL");
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState<number | null>(null);
  const [showPw, setShowPw] = useState(false);

  const load = async () => {
    try {
      const res = await fetch(`/api/admin/gmail?status=${filter}`);
      const data = await res.json();
      setList(data.submissions ?? []);
    } catch {
      toast("Gagal memuat data", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    load();
  }, [filter]);

  const action = async (id: number, act: string) => {
    setActing(id);
    try {
      const res = await fetch("/api/admin/gmail", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action: act }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal memproses", "error");
        return;
      }
      toast(
        act === "APPROVE"
          ? "Setoran disetujui, saldo ditambahkan"
          : "Setoran ditolak"
      );
      load();
    } catch {
      toast("Terjadi kesalahan", "error");
    } finally {
      setActing(null);
    }
  };

  const filtered =
    filter === "ALL"
      ? list
      : list.filter((s) => s.status === filter);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Setoran Masuk
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Verifikasi dan proses setoran Gmail dari member.
        </p>
      </div>

      <Card>
        <div className="flex flex-wrap gap-2 border-b border-slate-800 px-5 py-4">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`h-8 rounded-lg px-3 text-xs font-semibold transition cursor-pointer ${
                filter === f.key
                  ? "bg-gradient-to-r from-rose-500 to-red-500 text-white shadow-lg shadow-rose-500/25"
                  : "border border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-14">
            <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={<Inbox className="h-6 w-6" />}
            title="Tidak ada setoran"
            description="Setoran dari member akan muncul di sini."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Akun Gmail
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Password
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    User
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Status
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Harga
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Tanggal
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Aksi
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr
                    key={s.id}
                    className="border-b border-slate-800/50 transition hover:bg-slate-800/30"
                  >
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-slate-200">
                          {s.accountEmail}
                        </span>
                        <CopyButton text={s.accountEmail} />
                      </div>
                      {s.recoveryPhone && (
                        <p className="mt-1 text-[11px] text-slate-500">
                          HP: {s.recoveryPhone}
                        </p>
                      )}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-slate-500">
                          {showPw ? s.accountPassword : "••••••••"}
                        </span>
                        <button
                          onClick={() => setShowPw(!showPw)}
                          className="text-slate-500 hover:text-white cursor-pointer"
                        >
                          {showPw ? (
                            <EyeOff className="h-3.5 w-3.5" />
                          ) : (
                            <Eye className="h-3.5 w-3.5" />
                          )}
                        </button>
                        <CopyButton text={s.accountPassword} />
                      </div>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <p className="text-xs font-medium text-slate-200">
                        {s.userName}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        {s.userEmail}
                      </p>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <StatusBadge status={s.status} />
                      {s.adminNote && (
                        <p className="mt-1 text-[11px] text-slate-500">
                          {s.adminNote}
                        </p>
                      )}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <span className="font-semibold text-emerald-400">
                        +{formatIDR(s.price)}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5 text-xs text-slate-400">
                      {formatDateTime(s.createdAt)}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      {s.status === "PENDING" && (
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="success"
                            onClick={() => action(s.id, "APPROVE")}
                            disabled={acting === s.id}
                          >
                            {acting === s.id ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            )}
                            Setujui
                          </Button>
                          <Button
                            size="sm"
                            variant="danger"
                            onClick={() => action(s.id, "REJECT")}
                            disabled={acting === s.id}
                          >
                            <XCircle className="h-3.5 w-3.5" />
                            Tolak
                          </Button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
