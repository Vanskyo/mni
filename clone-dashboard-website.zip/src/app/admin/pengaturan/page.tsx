"use client";

import { useEffect, useState } from "react";
import { Settings, Loader2, Save } from "lucide-react";
import {
  Card,
  CardHeader,
  Button,
  Input,
  Field,
  useToast,
} from "@/components/ui";
import { formatIDR } from "@/lib/utils";

interface SettingsData {
  siteName: string;
  pricePerGmail: number;
  minWithdrawal: number;
  referralBonus: number;
  withdrawalFee: number;
}

export default function AdminPengaturanPage() {
  const { toast } = useToast();
  const [form, setForm] = useState<SettingsData>({
    siteName: "S3L GMAIL ZERO99",
    pricePerGmail: 4700,
    minWithdrawal: 25000,
    referralBonus: 500,
    withdrawalFee: 1500,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((d) => {
        if (d.settings) setForm(d.settings);
      })
      .catch(() => toast("Gagal memuat pengaturan", "error"))
      .finally(() => setLoading(false));
  }, []);

  const set = (k: keyof SettingsData, v: string | number) =>
    setForm((f) => ({ ...f, [k]: v }));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal menyimpan", "error");
        return;
      }
      toast("Pengaturan disimpan");
    } catch {
      toast("Terjadi kesalahan", "error");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Pengaturan
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Atur harga, biaya, dan bonus platform.
        </p>
      </div>

      <Card className="max-w-2xl">
        <CardHeader title="Pengaturan Platform" />
        <form onSubmit={save} className="space-y-4 p-5">
          <Field label="Nama Situs">
            <Input
              value={form.siteName}
              onChange={(e) => set("siteName", e.target.value)}
            />
          </Field>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Harga / Gmail">
              <Input
                type="number"
                value={form.pricePerGmail}
                onChange={(e) => set("pricePerGmail", Number(e.target.value))}
              />
              <span className="block text-xs text-slate-500">
                Saat ini: {formatIDR(form.pricePerGmail)}
              </span>
            </Field>
            <Field label="Minimal Penarikan">
              <Input
                type="number"
                value={form.minWithdrawal}
                onChange={(e) => set("minWithdrawal", Number(e.target.value))}
              />
              <span className="block text-xs text-slate-500">
                {formatIDR(form.minWithdrawal)}
              </span>
            </Field>
            <Field label="Bonus Referral / Gmail">
              <Input
                type="number"
                value={form.referralBonus}
                onChange={(e) => set("referralBonus", Number(e.target.value))}
              />
              <span className="block text-xs text-slate-500">
                {formatIDR(form.referralBonus)}
              </span>
            </Field>
            <Field label="Biaya Admin Penarikan">
              <Input
                type="number"
                value={form.withdrawalFee}
                onChange={(e) => set("withdrawalFee", Number(e.target.value))}
              />
              <span className="block text-xs text-slate-500">
                {formatIDR(form.withdrawalFee)}
              </span>
            </Field>
          </div>

          <Button type="submit" disabled={saving}>
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            Simpan Pengaturan
          </Button>
        </form>
      </Card>
    </div>
  );
}
