"use client";

import { useEffect, useState } from "react";
import {
  Megaphone,
  Plus,
  Trash2,
  Loader2,
} from "lucide-react";
import {
  Card,
  CardHeader,
  Button,
  Input,
  Textarea,
  Field,
  Modal,
  useToast,
} from "@/components/ui";
import { formatDateTime } from "@/lib/utils";

interface Announcement {
  id: number;
  title: string;
  content: string;
  createdAt: string;
}

export default function AdminPengumumanPage() {
  const { toast } = useToast();
  const [list, setList] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const res = await fetch("/api/admin/announcements");
      const data = await res.json();
      setList(data.announcements ?? []);
    } catch {
      toast("Gagal memuat data", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/admin/announcements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal membuat", "error");
        return;
      }
      toast("Pengumuman dibuat");
      setTitle("");
      setContent("");
      setOpen(false);
      load();
    } catch {
      toast("Terjadi kesalahan", "error");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: number) => {
    try {
      const res = await fetch(`/api/admin/announcements?id=${id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal menghapus", "error");
        return;
      }
      toast("Pengumuman dihapus");
      load();
    } catch {
      toast("Terjadi kesalahan", "error");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Pengumuman
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Kelola pengumuman untuk member.
          </p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" />
          Buat Pengumuman
        </Button>
      </div>

      <Card>
        <CardHeader title="Semua Pengumuman" />
        {loading ? (
          <div className="flex items-center justify-center py-14">
            <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
          </div>
        ) : list.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-14 text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-slate-800 bg-slate-800/50 text-slate-500">
              <Megaphone className="h-6 w-6" />
            </div>
            <p className="text-sm font-semibold text-slate-300">
              Belum ada pengumuman
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800">
            {list.map((a) => (
              <div
                key={a.id}
                className="flex items-start justify-between gap-4 px-5 py-4"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white">
                    {a.title}
                  </p>
                  <p className="mt-1 text-xs text-slate-400">
                    {a.content}
                  </p>
                  <p className="mt-1.5 text-[11px] text-slate-500">
                    {formatDateTime(a.createdAt)}
                  </p>
                </div>
                <button
                  onClick={() => remove(a.id)}
                  className="rounded-lg border border-slate-700 p-2 text-slate-400 transition hover:border-red-500/40 hover:text-red-400 cursor-pointer"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Buat Pengumuman"
      >
        <form onSubmit={create} className="space-y-4">
          <Field label="Judul">
            <Input
              placeholder="Contoh: Maintenance Server"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </Field>
          <Field label="Konten">
            <Textarea
              placeholder="Isi pengumuman..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              required
            />
          </Field>
          <div className="flex gap-2">
            <Button type="submit" className="flex-1" disabled={saving}>
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Megaphone className="h-4 w-4" />
              )}
              Simpan
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
            >
              Batal
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
