"use client";

import { useEffect, useState } from "react";
import {
  Wallet,
  CheckCircle2,
  XCircle,
  Loader2,
} from "lucide-react";
import {
  Card,
  CardHeader,
  StatusBadge,
  EmptyState,
  Badge,
  Button,
  useToast,
} from "@/components/ui";
import { formatIDR, formatDateTime } from "@/lib/utils";

interface Withdrawal {
  id: number;
  method: string;
  accountName: string;
  accountNumber: string;
  amount: number;
  fee: number;
  status: string;
  adminNote: string | null;
  createdAt: string;
  userName: string;
  userEmail: string;
}

const FILTERS = [
  { key: "ALL", label: "Semua" },
  { key: "PENDING", label: "Pending" },
  { key: "APPROVED", label: "Disetujui" },
  { key: "REJECTED", label: "Ditolak" },
];

export default function AdminPenarikanPage() {
  const { toast } = useToast();
  const [list, setList] = useState<Withdrawal[]>([]);
  const [filter, setFilter] = useState("ALL");
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState<number | null>(null);

  const load = async () => {
    try {
      const res = await fetch(`/api/admin/withdrawals?status=${filter}`);
      const data = await res.json();
      setList(data.withdrawals ?? []);
    } catch {
      toast("Gagal memuat data", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    load();
  }, [filter]);

  const action = async (id: number, act: string) => {
    setActing(id);
    try {
      const res = await fetch("/api/admin/withdrawals", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action: act }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal memproses", "error");
        return;
      }
      toast(
        act === "APPROVE"
          ? "Penarikan disetujui"
          : "Penarikan ditolak, saldo dikembalikan"
      );
      load();
    } catch {
      toast("Terjadi kesalahan", "error");
    } finally {
      setActing(null);
    }
  };

  const filtered =
    filter === "ALL"
      ? list
      : list.filter((w) => w.status === filter);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Penarikan
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Proses permintaan penarikan saldo member.
        </p>
      </div>

      <Card>
        <div className="flex flex-wrap gap-2 border-b border-slate-800 px-5 py-4">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`h-8 rounded-lg px-3 text-xs font-semibold transition cursor-pointer ${
                filter === f.key
                  ? "bg-gradient-to-r from-rose-500 to-red-500 text-white shadow-lg shadow-rose-500/25"
                  : "border border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-14">
            <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={<Wallet className="h-6 w-6" />}
            title="Tidak ada penarikan"
            description="Permintaan penarikan akan muncul di sini."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    User
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Metode
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Rekening
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Status
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Jumlah
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Tanggal
                  </th>
                  <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Aksi
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((w) => (
                  <tr
                    key={w.id}
                    className="border-b border-slate-800/50 transition hover:bg-slate-800/30"
                  >
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <p className="text-xs font-medium text-slate-200">
                        {w.userName}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        {w.userEmail}
                      </p>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <Badge variant="info">{w.method}</Badge>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <p className="font-mono text-xs text-slate-200">
                        {w.accountNumber}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        a/n {w.accountName}
                      </p>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <StatusBadge status={w.status} />
                      {w.adminNote && (
                        <p className="mt-1 text-[11px] text-slate-500">
                          {w.adminNote}
                        </p>
                      )}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <p className="font-semibold text-emerald-400">
                        {formatIDR(w.amount)}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        fee {formatIDR(w.fee)}
                      </p>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5 text-xs text-slate-400">
                      {formatDateTime(w.createdAt)}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      {w.status === "PENDING" && (
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="success"
                            onClick={() => action(w.id, "APPROVE")}
                            disabled={acting === w.id}
                          >
                            {acting === w.id ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            )}
                            Setujui
                          </Button>
                          <Button
                            size="sm"
                            variant="danger"
                            onClick={() => action(w.id, "REJECT")}
                            disabled={acting === w.id}
                          >
                            <XCircle className="h-3.5 w-3.5" />
                            Tolak
                          </Button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
