import { db } from "@/db";
import { users, gmailSubmissions, withdrawals } from "@/db/schema";
import { eq, sql, desc } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { formatIDR, formatNumber, formatDateTime } from "@/lib/utils";
import {
  Card,
  CardHeader,
  StatCard,
  StatusBadge,
  Badge,
} from "@/components/ui";
import {
  Users,
  Inbox,
  Wallet,
  CheckCircle2,
  Clock,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";
import Link from "next/link";

export default async function AdminPage() {
  await requireAdmin();
  const settings = await getSettings();

  const [userCount, gmailStats, wdStats] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(users),
    db
      .select({
        total: sql<number>`count(*)`,
        pending: sql<number>`sum(case when status = 'PENDING' then 1 else 0 end)`,
        approved: sql<number>`sum(case when status = 'APPROVED' then 1 else 0 end)`,
      })
      .from(gmailSubmissions),
    db
      .select({
        total: sql<number>`count(*)`,
        pending: sql<number>`sum(case when status = 'PENDING' then 1 else 0 end)`,
        paid: sql<number>`coalesce(sum(case when status = 'APPROVED' then amount else 0 end), 0)`,
      })
      .from(withdrawals),
  ]);

  const gs = gmailStats[0] ?? { total: 0, pending: 0, approved: 0 };
  const ws = wdStats[0] ?? { total: 0, pending: 0, paid: 0 };

  const recentSubmissions = await db
    .select({
      id: gmailSubmissions.id,
      accountEmail: gmailSubmissions.accountEmail,
      status: gmailSubmissions.status,
      price: gmailSubmissions.price,
      createdAt: gmailSubmissions.createdAt,
      userName: users.name,
    })
    .from(gmailSubmissions)
    .innerJoin(users, eq(gmailSubmissions.userId, users.id))
    .orderBy(desc(gmailSubmissions.createdAt))
    .limit(5);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-red-600 shadow-lg shadow-rose-500/30">
          <ShieldCheck className="h-5 w-5 text-white" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Admin Dashboard
          </h1>
          <p className="text-sm text-slate-500">
            Kelola setoran, penarikan, dan pengguna.
          </p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={<Users className="h-5 w-5" />}
          label="Total Pengguna"
          value={formatNumber(Number(userCount[0]?.count ?? 0))}
          sub="Member terdaftar"
          accent="rose"
        />
        <StatCard
          icon={<Inbox className="h-5 w-5" />}
          label="Setoran Pending"
          value={formatNumber(Number(gs.pending))}
          sub={`${formatNumber(Number(gs.total))} total`}
          accent="amber"
        />
        <StatCard
          icon={<Wallet className="h-5 w-5" />}
          label="Penarikan Pending"
          value={formatNumber(Number(ws.pending))}
          sub={`${formatIDR(Number(ws.paid))} dibayar`}
          accent="sky"
        />
        <StatCard
          icon={<CheckCircle2 className="h-5 w-5" />}
          label="Gmail Disetujui"
          value={formatNumber(Number(gs.approved))}
          sub={`${formatIDR(Number(gs.approved) * settings.pricePerGmail)} dibagikan`}
          accent="emerald"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Quick actions */}
        <Card>
          <CardHeader title="Aksi Cepat" />
          <div className="grid gap-3 p-5 sm:grid-cols-2">
            {[
              { href: "/admin/setoran", label: "Setoran Masuk", icon: Inbox, count: Number(gs.pending) },
              { href: "/admin/penarikan", label: "Penarikan", icon: Wallet, count: Number(ws.pending) },
              { href: "/admin/pengguna", label: "Pengguna", icon: Users, count: Number(userCount[0]?.count ?? 0) },
              { href: "/admin/pengaturan", label: "Pengaturan", icon: ShieldCheck, count: 0 },
            ].map((a) => (
              <Link
                key={a.href}
                href={a.href}
                className="group flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/60 p-4 transition hover:border-rose-500/30"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-500/10 text-rose-400">
                    <a.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">
                      {a.label}
                    </p>
                    {a.count > 0 && (
                      <p className="text-xs text-slate-500">
                        {formatNumber(a.count)} item
                      </p>
                    )}
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-600 transition group-hover:text-rose-400" />
              </Link>
            ))}
          </div>
        </Card>

        {/* Recent submissions */}
        <Card>
          <CardHeader
            title="Setoran Terbaru"
            action={
              <Link
                href="/admin/setoran"
                className="inline-flex items-center gap-1 text-xs font-semibold text-rose-400 hover:text-rose-300"
              >
                Lihat Semua
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            }
          />
          <div className="divide-y divide-slate-800">
            {recentSubmissions.map((r) => (
              <div
                key={r.id}
                className="flex items-center justify-between gap-4 px-5 py-3.5"
              >
                <div className="min-w-0">
                  <p className="truncate font-mono text-sm text-slate-200">
                    {r.accountEmail}
                  </p>
                  <p className="text-xs text-slate-500">
                    {r.userName} • {formatDateTime(r.createdAt)}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold text-emerald-400">
                    +{formatIDR(r.price)}
                  </span>
                  <StatusBadge status={r.status} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
