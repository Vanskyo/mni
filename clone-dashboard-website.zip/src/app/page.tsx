"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Mail,
  Zap,
  ShieldCheck,
  Gift,
  Wallet,
  Headset,
  Bot,
  ChevronDown,
  ArrowRight,
  CheckCircle2,
  TrendingUp,
  Users,
  Send,
  Clock,
  Sparkles,
} from "lucide-react";
import { formatNumber, formatIDR } from "@/lib/utils";

const FEATURES = [
  {
    icon: Zap,
    title: "Pembayaran Instan",
    desc: "Saldo masuk otomatis begitu setoran Gmail Anda disetujui oleh sistem.",
  },
  {
    icon: Bot,
    title: "Sistem Otomatis",
    desc: "Proses verifikasi dan pembayaran berjalan otomatis tanpa antre lama.",
  },
  {
    icon: Gift,
    title: "Bonus Referral",
    desc: "Ajak teman, dapatkan bonus untuk setiap Gmail yang mereka setorkan.",
  },
  {
    icon: ShieldCheck,
    title: "100% Aman",
    desc: "Data akun Anda terenkripsi dan tidak dibagikan ke pihak manapun.",
  },
  {
    icon: Wallet,
    title: "Tarik Saldo Fleksibel",
    desc: "Tarik ke DANA, GoPay, OVO, atau BCA kapan saja tanpa ribet.",
  },
  {
    icon: Headset,
    title: "Support 24/7",
    desc: "Tim admin siap membantu Anda melalui tiket bantuan setiap saat.",
  },
];

const STEPS = [
  {
    icon: Users,
    step: "01",
    title: "Daftar & Login",
    desc: "Buat akun gratis, gunakan kode referral jika ada untuk bonus ekstra.",
  },
  {
    icon: Send,
    step: "02",
    title: "Setor Gmail",
    desc: "Generate atau masukkan akun Gmail Anda melalui halaman Setoran.",
  },
  {
    icon: TrendingUp,
    step: "03",
    title: "Cuan Langsung",
    desc: "Gmail disetujui, saldo bertambah, tarik kapan saja!",
  },
];

const FAQS = [
  {
    q: "Berapa harga per Gmail?",
    a: "Harga per Gmail adalah Rp4.700. Harga bisa berubah sewaktu-waktu sesuai kebijakan, cek halaman Setoran untuk info terbaru.",
  },
  {
    q: "Kapan saldo saya masuk?",
    a: "Saldo masuk secara otomatis setelah admin menyetujui setoran Anda. Proses verifikasi biasanya kurang dari 5 menit.",
  },
  {
    q: "Bagaimana cara menarik saldo?",
    a: "Buka menu Tarik Saldo, pilih metode (DANA/GoPay/OVO/BCA), isi nomor dan jumlah, lalu kirim. Penarikan diproses 1-2 menit setelah disetujui.",
  },
  {
    q: "Apakah ada minimal penarikan?",
    a: "Ya, minimal penarikan adalah Rp25.000. Biaya admin penarikan Rp1.500 per transaksi.",
  },
  {
    q: "Apakah program referral menguntungkan?",
    a: "Sangat! Anda mendapat Rp500 untuk setiap Gmail yang disetujui dari referral Anda, tanpa batas.",
  },
];

export default function LandingPage() {
  const [stats, setStats] = useState({
    members: 12480,
    totalGmail: 89340,
    approvedGmail: 87120,
    paidOut: 409344000,
    pricePerGmail: 4700,
  });
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  useEffect(() => {
    fetch("/api/stats")
      .then((r) => r.json())
      .then((d) => {
        if (d && typeof d.members === "number") setStats(d);
      })
      .catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Navbar */}
      <header className="fixed top-0 inset-x-0 z-50 border-b border-slate-800/60 bg-slate-950/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <Link href="/" className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-red-600 shadow-lg shadow-rose-500/30">
              <Mail className="h-4.5 w-4.5 text-white" />
            </div>
            <div>
              <p className="font-display text-sm font-bold leading-tight">
                S3L GMAIL
              </p>
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-rose-400">
                Zero99
              </p>
            </div>
          </Link>

          <nav className="hidden items-center gap-8 text-sm text-slate-400 md:flex">
            <a href="#fitur" className="transition hover:text-white">Fitur</a>
            <a href="#cara" className="transition hover:text-white">Cara Kerja</a>
            <a href="#penghasilan" className="transition hover:text-white">Penghasilan</a>
            <a href="#faq" className="transition hover:text-white">FAQ</a>
          </nav>

          <div className="flex items-center gap-3">
            <Link href="/auth" className="hidden text-sm font-medium text-slate-300 transition hover:text-white sm:block">
              Masuk
            </Link>
            <Link
              href="/auth"
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-gradient-to-r from-rose-500 to-red-500 px-4 text-sm font-semibold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110"
            >
              Daftar Sekarang
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden pt-32 pb-20">
        <div className="grid-bg absolute inset-0" />
        <div className="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2 h-96 w-[600px] rounded-full bg-rose-500/15 blur-[120px]" />

        <div className="relative mx-auto max-w-6xl px-4">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-rose-500/30 bg-rose-500/10 px-4 py-1.5 text-xs font-semibold text-rose-300">
              <Sparkles className="h-3.5 w-3.5" />
              Platform Setoran Gmail Terpercaya
            </div>
            <h1 className="font-display text-4xl font-bold leading-[1.1] tracking-tight sm:text-6xl">
              Cuan dari{" "}
              <span className="bg-gradient-to-r from-rose-400 via-red-400 to-rose-400 bg-clip-text text-transparent">
                Setoran Gmail
              </span>
              , Cepat & Aman
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-base text-slate-400 sm:text-lg">
              Daftarkan akun Gmail Anda, kami bayar per akun. Sistem otomatis,
              saldo instan, penarikan 1-2 menit.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link
                href="/auth"
                className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-rose-500 to-red-500 px-8 text-base font-semibold text-white shadow-xl shadow-rose-500/30 transition hover:brightness-110 sm:w-auto"
              >
                Mulai Cuan Sekarang
                <ArrowRight className="h-5 w-5" />
              </Link>
              <a
                href="#cara"
                className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900/60 px-8 text-base font-semibold text-slate-200 transition hover:bg-slate-800 sm:w-auto"
              >
                Lihat Cara Kerja
              </a>
            </div>

            {/* Stats */}
            <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {[
                { icon: Users, label: "Member Aktif", value: formatNumber(stats.members) },
                { icon: Mail, label: "Gmail Disetor", value: formatNumber(stats.totalGmail) },
                { icon: CheckCircle2, label: "Gmail Disetujui", value: formatNumber(stats.approvedGmail) },
                { icon: Wallet, label: "Total Dibayar", value: formatIDR(stats.paidOut) },
              ].map((s) => (
                <div
                  key={s.label}
                  className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 backdrop-blur-sm"
                >
                  <s.icon className="mx-auto mb-2 h-5 w-5 text-rose-400" />
                  <p className="font-display text-lg font-bold text-white">
                    {s.value}
                  </p>
                  <p className="text-[11px] text-slate-500">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Dashboard mockup */}
          <div className="relative mx-auto mt-16 max-w-4xl">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-to-r from-rose-500/20 via-red-500/10 to-rose-500/20 blur-2xl" />
            <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/90 shadow-2xl">
              <div className="flex items-center gap-2 border-b border-slate-800 px-4 py-3">
                <span className="h-3 w-3 rounded-full bg-red-500/70" />
                <span className="h-3 w-3 rounded-full bg-amber-500/70" />
                <span className="h-3 w-3 rounded-full bg-emerald-500/70" />
                <span className="ml-3 text-xs text-slate-500">
                  zero99gmail.com/dashboard
                </span>
              </div>
              <div className="grid gap-4 p-5 sm:grid-cols-3">
                <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                  <p className="text-[11px] text-slate-500">Saldo</p>
                  <p className="mt-1 font-display text-xl font-bold text-emerald-400">
                    Rp1.250.000
                  </p>
                </div>
                <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                  <p className="text-[11px] text-slate-500">Disetujui</p>
                  <p className="mt-1 font-display text-xl font-bold text-white">
                    124
                  </p>
                </div>
                <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                  <p className="text-[11px] text-slate-500">Pending</p>
                  <p className="mt-1 font-display text-xl font-bold text-amber-400">
                    12
                  </p>
                </div>
              </div>
              <div className="space-y-2 px-5 pb-5">
                {[
                  { e: "budi.santoso123@gmail.com", s: "Disetujui", c: "text-emerald-400" },
                  { e: "siti.wijaya456@gmail.com", s: "Pending", c: "text-amber-400" },
                  { e: "andi.pratama789@gmail.com", s: "Disetujui", c: "text-emerald-400" },
                ].map((r) => (
                  <div
                    key={r.e}
                    className="flex items-center justify-between rounded-lg border border-slate-800/80 bg-slate-950/40 px-4 py-2.5"
                  >
                    <span className="font-mono text-xs text-slate-300">{r.e}</span>
                    <span className={`text-xs font-semibold ${r.c}`}>{r.s}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="fitur" className="relative py-20">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-rose-400">
              Fitur Unggulan
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">
              Semua yang Anda butuhkan untuk cuan
            </h2>
            <p className="mt-4 text-slate-400">
              Platform lengkap dengan sistem otomatis, pembayaran instan, dan
              pengelolaan admin yang profesional.
            </p>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="group rounded-2xl border border-slate-800 bg-slate-900/60 p-6 transition-all hover:border-rose-500/30 hover:bg-slate-900"
              >
                <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl border border-rose-500/20 bg-rose-500/10 text-rose-400 transition group-hover:scale-110">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="font-display text-base font-semibold text-white">
                  {f.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">
                  {f.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="cara" className="relative py-20">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-rose-400">
              Cara Kerja
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">
              Mulai cuan dalam 3 langkah
            </h2>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {STEPS.map((s) => (
              <div
                key={s.step}
                className="relative rounded-2xl border border-slate-800 bg-slate-900/60 p-6"
              >
                <span className="absolute right-5 top-5 font-display text-4xl font-bold text-slate-800">
                  {s.step}
                </span>
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500/20 to-red-500/10 text-rose-400 border border-rose-500/20">
                  <s.icon className="h-6 w-6" />
                </div>
                <h3 className="font-display text-lg font-semibold text-white">
                  {s.title}
                </h3>
                <p className="mt-2 text-sm text-slate-400">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Rate */}
      <section id="penghasilan" className="relative py-20">
        <div className="mx-auto max-w-4xl px-4">
          <div className="relative overflow-hidden rounded-3xl border border-rose-500/20 bg-gradient-to-br from-rose-950/40 via-slate-900 to-slate-900 p-8 sm:p-12">
            <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-rose-500/20 blur-[80px]" />
            <div className="relative grid gap-8 sm:grid-cols-2">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-rose-400">
                  Penghasilan
                </p>
                <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">
                  1 Gmail ={" "}
                  <span className="bg-gradient-to-r from-rose-400 to-red-400 bg-clip-text text-transparent">
                    {formatIDR(stats.pricePerGmail)}
                  </span>
                </h2>
                <p className="mt-4 text-sm text-slate-400">
                  Tidak ada batasan berapa banyak Gmail yang bisa Anda setorkan.
                  Semakin banyak setoran, semakin besar cuan Anda.
                </p>
              </div>
              <div className="space-y-3">
                {[
                  "10 Gmail / hari = Rp47.000",
                  "50 Gmail / hari = Rp235.000",
                  "100 Gmail / hari = Rp470.000",
                  "300 Gmail / bulan = Rp1.410.000",
                ].map((t) => (
                  <div
                    key={t}
                    className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-950/60 px-4 py-3"
                  >
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                    <span className="text-sm font-medium text-slate-200">
                      {t}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative mt-8 text-center">
              <Link
                href="/auth"
                className="inline-flex h-12 items-center gap-2 rounded-xl bg-gradient-to-r from-rose-500 to-red-500 px-8 text-base font-semibold text-white shadow-xl shadow-rose-500/30 transition hover:brightness-110"
              >
                Klaim Penghasilan Anda
                <ArrowRight className="h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="relative py-20">
        <div className="mx-auto max-w-3xl px-4">
          <div className="text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-rose-400">
              FAQ
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">
              Pertanyaan Umum
            </h2>
          </div>

          <div className="mt-10 space-y-3">
            {FAQS.map((f, i) => (
              <div
                key={i}
                className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left cursor-pointer"
                >
                  <span className="text-sm font-semibold text-slate-200">
                    {f.q}
                  </span>
                  <ChevronDown
                    className={`h-4 w-4 shrink-0 text-slate-500 transition-transform ${
                      openFaq === i ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {openFaq === i && (
                  <p className="px-5 pb-4 text-sm leading-relaxed text-slate-400">
                    {f.a}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-20">
        <div className="mx-auto max-w-4xl px-4">
          <div className="relative overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-br from-rose-600 via-red-600 to-rose-700 p-10 text-center sm:p-16">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImciIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA4Ii8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2cpIi8+PC9zdmc+')]" />
            <div className="relative">
              <h2 className="font-display text-3xl font-bold text-white sm:text-4xl">
                Siap mulai cuan?
              </h2>
              <p className="mx-auto mt-4 max-w-md text-rose-100">
                Bergabung dengan {formatNumber(stats.members)}+ member lainnya.
                Pendaftaran gratis, tanpa biaya apapun.
              </p>
              <Link
                href="/auth"
                className="mt-8 inline-flex h-12 items-center gap-2 rounded-xl bg-white px-8 text-base font-semibold text-rose-600 shadow-xl transition hover:bg-rose-50"
              >
                Daftar Gratis Sekarang
                <ArrowRight className="h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 sm:flex-row">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-rose-500 to-red-600">
              <Mail className="h-4 w-4 text-white" />
            </div>
            <span className="font-display text-sm font-bold">
              S3L GMAIL <span className="text-rose-400">ZERO99</span>
            </span>
          </div>
          <p className="text-xs text-slate-500">
            © 2026 S3L GMAIL ZERO99. Setoran Gmail Cepat & Aman.
          </p>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Clock className="h-3.5 w-3.5" />
            Support 24/7
          </div>
        </div>
      </footer>
    </div>
  );
}
