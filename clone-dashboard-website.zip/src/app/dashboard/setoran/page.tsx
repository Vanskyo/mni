import { db } from "@/db";
import { gmailSubmissions } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { formatIDR, formatNumber } from "@/lib/utils";
import {
  Card,
  CardHeader,
  Badge,
  EmptyState,
  StatusBadge,
  Button,
} from "@/components/ui";
import {
  Sparkles,
  Send,
  Trash2,
  Plus,
  Info,
  Mail,
  ShieldCheck,
  TrendingUp,
} from "lucide-react";
import { GmailGenerator } from "./GmailGenerator";

export default async function SetoranPage() {
  const user = await requireUser();
  const settings = await getSettings();

  const pending = await db
    .select()
    .from(gmailSubmissions)
    .where(eq(gmailSubmissions.userId, user.id))
    .orderBy(desc(gmailSubmissions.createdAt))
    .limit(50);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Setoran Gmail
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Generate atau masukkan akun Gmail untuk disetorkan.
        </p>
      </div>

      {/* Info cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-500/10 text-rose-400">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Harga / Gmail</p>
              <p className="font-display text-xl font-bold text-white">
                {formatIDR(settings.pricePerGmail)}
              </p>
            </div>
          </div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/10 text-amber-400">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Belum Diproses</p>
              <p className="font-display text-xl font-bold text-white">
                {pending.length}
              </p>
            </div>
          </div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Status</p>
              <p className="font-display text-xl font-bold text-emerald-400">
                Aman
              </p>
            </div>
          </div>
        </Card>
      </div>

      <GmailGenerator
        pricePerGmail={settings.pricePerGmail}
        existingCount={pending.length}
      />

      {/* Pending list */}
      <Card>
        <CardHeader
          title="Setoran Belum Diproses"
          subtitle="Akun yang menunggu verifikasi admin"
        />
        {pending.length === 0 ? (
          <EmptyState
            icon={<Mail className="h-6 w-6" />}
            title="Belum ada setoran pending"
            description="Gunakan generator di atas untuk membuat setoran baru."
          />
        ) : (
          <div className="divide-y divide-slate-800">
            {pending.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between gap-4 px-5 py-3.5"
              >
                <div className="min-w-0">
                  <p className="truncate font-mono text-sm text-slate-200">
                    {p.accountEmail}
                  </p>
                  <p className="text-xs text-slate-500">
                    {p.recoveryPhone ? `HP: ${p.recoveryPhone}` : "Tanpa HP"}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold text-emerald-400">
                    +{formatIDR(p.price)}
                  </span>
                  <StatusBadge status={p.status} />
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
