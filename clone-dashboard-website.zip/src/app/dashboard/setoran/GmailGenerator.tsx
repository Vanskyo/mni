"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Sparkles,
  Send,
  Trash2,
  Plus,
  Info,
  Mail,
  CheckCircle2,
  Loader2,
} from "lucide-react";
import { Card, CardHeader, Button, Input, Badge, useToast } from "@/components/ui";
import {
  randomGmailAddress,
  randomPassword,
  formatIDR,
} from "@/lib/utils";

interface Item {
  email: string;
  password: string;
  phone: string;
}

export function GmailGenerator({
  pricePerGmail,
  existingCount,
}: {
  pricePerGmail: number;
  existingCount: number;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [items, setItems] = useState<Item[]>([]);
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);

  const addOne = () => {
    setItems((arr) => [
      ...arr,
      { email: randomGmailAddress(), password: randomPassword(), phone },
    ]);
  };

  const addBatch = (n: number) => {
    const batch: Item[] = [];
    for (let i = 0; i < n; i++) {
      batch.push({
        email: randomGmailAddress(),
        password: randomPassword(),
        phone,
      });
    }
    setItems((arr) => [...arr, ...batch]);
  };

  const remove = (idx: number) =>
    setItems((arr) => arr.filter((_, i) => i !== idx));

  const update = (idx: number, field: keyof Item, value: string) =>
    setItems((arr) =>
      arr.map((it, i) => (i === idx ? { ...it, [field]: value } : it))
    );

  const submit = async () => {
    if (items.length === 0) {
      toast("Tambahkan akun Gmail terlebih dahulu", "error");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/gmail", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal mengirim setoran", "error");
        return;
      }
      toast(
        `${data.count} Gmail berhasil disetorkan! Potensi ${formatIDR(data.total)}`
      );
      setItems([]);
      router.refresh();
    } catch {
      toast("Terjadi kesalahan jaringan", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader
        title="Generator Gmail"
        subtitle="Generate otomatis email & password, lalu kirim sebagai setoran"
        action={
          <Badge variant="rose">
            <Sparkles className="h-3 w-3" />
            Otomatis
          </Badge>
        }
      />
      <div className="p-5">
        {/* Phone + generate buttons */}
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="flex-1">
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
              No. HP Pemulihan (opsional)
            </label>
            <Input
              placeholder="081234567890"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="flex flex-wrap items-end gap-2">
            <Button onClick={addOne} variant="secondary">
              <Plus className="h-4 w-4" />
              Generate 1
            </Button>
            <Button onClick={() => addBatch(5)} variant="secondary">
              <Sparkles className="h-4 w-4" />
              Generate 5
            </Button>
            <Button onClick={() => addBatch(10)} variant="secondary">
              <Sparkles className="h-4 w-4" />
              Generate 10
            </Button>
          </div>
        </div>

        {/* Items list */}
        {items.length > 0 && (
          <div className="mt-5 space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Daftar Akun ({items.length})
              </p>
              <p className="text-xs text-slate-500">
                Potensi total:{" "}
                <span className="font-semibold text-emerald-400">
                  {formatIDR(items.length * pricePerGmail)}
                </span>
              </p>
            </div>
            <div className="max-h-80 space-y-2 overflow-y-auto pr-1">
              {items.map((item, idx) => (
                <div
                  key={idx}
                  className="flex flex-col gap-2 rounded-xl border border-slate-800 bg-slate-950/60 p-3 sm:flex-row sm:items-center"
                >
                  <div className="flex-1 space-y-2">
                    <Input
                      value={item.email}
                      onChange={(e) => update(idx, "email", e.target.value)}
                      className="font-mono text-xs"
                    />
                    <Input
                      value={item.password}
                      onChange={(e) => update(idx, "password", e.target.value)}
                      className="font-mono text-xs"
                    />
                  </div>
                  <button
                    onClick={() => remove(idx)}
                    className="rounded-lg border border-slate-700 p-2 text-slate-400 transition hover:border-red-500/40 hover:text-red-400 cursor-pointer"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Submit */}
        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Info className="h-3.5 w-3.5" />
            Maksimal 20 akun per pengiriman
          </div>
          <Button
            onClick={submit}
            disabled={loading || items.length === 0}
            size="lg"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
            {loading
              ? "Mengirim..."
              : `Kirim ${items.length} Setoran`}
          </Button>
        </div>
      </div>
    </Card>
  );
}
