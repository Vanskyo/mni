import type { ReactNode } from "react";
import { requireUser } from "@/lib/auth";
import { DashboardSidebar } from "@/components/Sidebar";
import { ToastProvider } from "@/components/ui";

export default async function DashboardLayout({
  children,
}: {
  children: ReactNode;
}) {
  const user = await requireUser();

  return (
    <ToastProvider>
      <div className="min-h-screen bg-slate-950">
        <DashboardSidebar
          user={{
            name: user.name,
            email: user.email,
            balance: user.balance,
            role: user.role,
          }}
        />
        <main className="lg:pl-64">
          <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8">
            {children}
          </div>
        </main>
      </div>
    </ToastProvider>
  );
}
