import { db } from "@/db";
import { withdrawals } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { formatIDR, formatDateTime } from "@/lib/utils";
import {
  Card,
  CardHeader,
  StatCard,
  StatusBadge,
  EmptyState,
  Badge,
} from "@/components/ui";
import {
  Wallet,
  TrendingUp,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { WithdrawalForm } from "./WithdrawalForm";

export default async function TarikSaldoPage() {
  const user = await requireUser();
  const settings = await getSettings();

  const list = await db
    .select()
    .from(withdrawals)
    .where(eq(withdrawals.userId, user.id))
    .orderBy(desc(withdrawals.createdAt))
    .limit(50);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Tarik Saldo
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Tarik saldo Anda ke DANA, GoPay, OVO, atau BCA.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard
          icon={<Wallet className="h-5 w-5" />}
          label="Saldo Tersedia"
          value={formatIDR(user.balance)}
          sub="Siap ditarik"
          accent="emerald"
        />
        <StatCard
          icon={<TrendingUp className="h-5 w-5" />}
          label="Minimal Tarik"
          value={formatIDR(settings.minWithdrawal)}
          sub="Per transaksi"
          accent="rose"
        />
        <StatCard
          icon={<Clock className="h-5 w-5" />}
          label="Biaya Admin"
          value={formatIDR(settings.withdrawalFee)}
          sub="Dipotong per tarikan"
          accent="amber"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <WithdrawalForm
          balance={user.balance}
          minWithdrawal={settings.minWithdrawal}
          fee={settings.withdrawalFee}
        />

        <Card>
          <CardHeader
            title="Riwayat Penarikan"
            subtitle={`${list.length} transaksi`}
          />
          {list.length === 0 ? (
            <EmptyState
              icon={<Wallet className="h-6 w-6" />}
              title="Belum ada penarikan"
              description="Riwayat penarikan Anda akan muncul di sini."
            />
          ) : (
            <div className="divide-y divide-slate-800">
              {list.map((w) => (
                <div
                  key={w.id}
                  className="flex items-center justify-between gap-4 px-5 py-3.5"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Badge variant="info">{w.method}</Badge>
                      <span className="font-mono text-xs text-slate-300">
                        {w.accountNumber}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">
                      {formatDateTime(w.createdAt)}
                    </p>
                    {w.adminNote && (
                      <p className="mt-0.5 text-[11px] text-slate-500">
                        {w.adminNote}
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-emerald-400">
                      {formatIDR(w.amount)}
                    </p>
                    <StatusBadge status={w.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
