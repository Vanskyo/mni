"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Wallet, Loader2, Info } from "lucide-react";
import { Card, CardHeader, Button, Input, Select, Field, useToast } from "@/components/ui";
import { formatIDR } from "@/lib/utils";

export function WithdrawalForm({
  balance,
  minWithdrawal,
  fee,
}: {
  balance: number;
  minWithdrawal: number;
  fee: number;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [method, setMethod] = useState("DANA");
  const [accountName, setAccountName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);

  const numAmount = Math.floor(Number(amount) || 0);
  const net = Math.max(0, numAmount - fee);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (numAmount < minWithdrawal) {
      toast(`Minimal penarikan ${formatIDR(minWithdrawal)}`, "error");
      return;
    }
    if (numAmount > balance) {
      toast("Saldo tidak mencukupi", "error");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/withdraw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method, accountName, accountNumber, amount: numAmount }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal mengajukan penarikan", "error");
        return;
      }
      toast(
        `Penarikan ${formatIDR(data.amount)} diajukan! Diterima: ${formatIDR(data.amount)}`
      );
      setAmount("");
      router.refresh();
    } catch {
      toast("Terjadi kesalahan jaringan", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader
        title="Ajukan Penarikan"
        subtitle="Saldo akan dipotong saat pengajuan"
      />
      <form onSubmit={submit} className="space-y-4 p-5">
        <Field label="Metode">
          <Select value={method} onChange={(e) => setMethod(e.target.value)}>
            <option value="DANA">DANA</option>
            <option value="GOPAY">GoPay</option>
            <option value="OVO">OVO</option>
            <option value="BCA">BCA</option>
          </Select>
        </Field>

        <Field label="Nama Pemilik">
          <Input
            placeholder="Nama sesuai rekening/dompet"
            value={accountName}
            onChange={(e) => setAccountName(e.target.value)}
            required
          />
        </Field>

        <Field label="Nomor Rekening / Dompet">
          <Input
            placeholder="081234567890 / 1234567890"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            required
          />
        </Field>

        <Field label="Jumlah">
          <Input
            type="number"
            placeholder={`Minimal ${minWithdrawal}`}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
          <span className="block text-xs text-slate-500">
            Diterima: {formatIDR(net)} (biaya admin {formatIDR(fee)})
          </span>
        </Field>

        <div className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-950/60 px-4 py-3 text-xs text-slate-400">
          <Info className="h-3.5 w-3.5 shrink-0" />
          Saldo tersedia:{" "}
          <span className="font-semibold text-emerald-400">
            {formatIDR(balance)}
          </span>
        </div>

        <Button type="submit" size="lg" className="w-full" disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wallet className="h-4 w-4" />}
          {loading ? "Memproses..." : "Ajukan Penarikan"}
        </Button>
      </form>
    </Card>
  );
}
