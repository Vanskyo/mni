"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Trash2, Mail, Copy, History as HistoryIcon } from "lucide-react";
import {
  Card,
  StatusBadge,
  EmptyState,
  CopyButton,
  Badge,
  useToast,
} from "@/components/ui";
import { formatIDR, formatDateTime } from "@/lib/utils";
import type { GmailSubmission } from "@/db/schema";

const FILTERS = [
  { key: "ALL", label: "Semua" },
  { key: "PENDING", label: "Pending" },
  { key: "APPROVED", label: "Disetujui" },
  { key: "REJECTED", label: "Ditolak" },
];

export function RiwayatTable({
  submissions,
}: {
  submissions: GmailSubmission[];
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [filter, setFilter] = useState("ALL");
  const [deleting, setDeleting] = useState<number | null>(null);

  const filtered =
    filter === "ALL"
      ? submissions
      : submissions.filter((s) => s.status === filter);

  const remove = async (id: number) => {
    setDeleting(id);
    try {
      const res = await fetch(`/api/gmail/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal menghapus", "error");
        return;
      }
      toast("Setoran dihapus");
      router.refresh();
    } catch {
      toast("Terjadi kesalahan", "error");
    } finally {
      setDeleting(null);
    }
  };

  if (submissions.length === 0) {
    return (
      <EmptyState
        icon={<HistoryIcon className="h-6 w-6" />}
        title="Belum ada riwayat"
        description="Setoran Gmail Anda akan muncul di sini."
      />
    );
  }

  return (
    <div>
      {/* Filters */}
      <div className="flex flex-wrap gap-2 border-b border-slate-800 px-5 py-4">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`h-8 rounded-lg px-3 text-xs font-semibold transition cursor-pointer ${
              filter === f.key
                ? "bg-gradient-to-r from-rose-500 to-red-500 text-white shadow-lg shadow-rose-500/25"
                : "border border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-white"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<Mail className="h-6 w-6" />}
          title="Tidak ada data"
          description="Tidak ada setoran dengan status ini."
        />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Email
                </th>
                <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Password
                </th>
                <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Status
                </th>
                <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Harga
                </th>
                <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Tanggal
                </th>
                <th className="whitespace-nowrap px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => (
                <tr
                  key={s.id}
                  className="border-b border-slate-800/50 transition hover:bg-slate-800/30"
                >
                  <td className="whitespace-nowrap px-5 py-3.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-slate-200">
                        {s.accountEmail}
                      </span>
                      <CopyButton text={s.accountEmail} />
                    </div>
                  </td>
                  <td className="whitespace-nowrap px-5 py-3.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-slate-500">
                        {s.accountPassword.slice(0, 8)}•••
                      </span>
                      <CopyButton text={s.accountPassword} />
                    </div>
                  </td>
                  <td className="whitespace-nowrap px-5 py-3.5">
                    <StatusBadge status={s.status} />
                    {s.adminNote && (
                      <p className="mt-1 text-[11px] text-slate-500">
                        {s.adminNote}
                      </p>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-5 py-3.5">
                    <span className="font-semibold text-emerald-400">
                      +{formatIDR(s.price)}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-5 py-3.5 text-xs text-slate-400">
                    {formatDateTime(s.createdAt)}
                  </td>
                  <td className="whitespace-nowrap px-5 py-3.5">
                    {s.status === "PENDING" && (
                      <button
                        onClick={() => remove(s.id)}
                        disabled={deleting === s.id}
                        className="rounded-lg border border-slate-700 p-2 text-slate-400 transition hover:border-red-500/40 hover:text-red-400 disabled:opacity-50 cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
