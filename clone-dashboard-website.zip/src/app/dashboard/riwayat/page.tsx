import { db } from "@/db";
import { gmailSubmissions } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { formatIDR, formatDateTime } from "@/lib/utils";
import {
  Card,
  CardHeader,
  StatusBadge,
  EmptyState,
  CopyButton,
  Badge,
} from "@/components/ui";
import { History, Trash2, Mail, Copy } from "lucide-react";
import { RiwayatTable } from "./RiwayatTable";

export default async function RiwayatPage() {
  const user = await requireUser();

  const list = await db
    .select()
    .from(gmailSubmissions)
    .where(eq(gmailSubmissions.userId, user.id))
    .orderBy(desc(gmailSubmissions.createdAt))
    .limit(100);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Riwayat Setoran
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Semua setoran Gmail Anda, lengkap dengan statusnya.
        </p>
      </div>

      <Card>
        <CardHeader
          title="Semua Setoran"
          subtitle={`${list.length} total setoran`}
        />
        <RiwayatTable submissions={list} />
      </Card>
    </div>
  );
}
