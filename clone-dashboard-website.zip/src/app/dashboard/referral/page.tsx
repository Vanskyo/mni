import { db } from "@/db";
import { users, gmailSubmissions } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { formatIDR, formatNumber, formatDateTime } from "@/lib/utils";
import {
  Card,
  CardHeader,
  StatCard,
  EmptyState,
  CopyButton,
  Badge,
} from "@/components/ui";
import {
  Gift,
  Users,
  TrendingUp,
  Link2,
  Mail,
  CheckCircle2,
} from "lucide-react";

export default async function ReferralPage() {
  const user = await requireUser();
  const settings = await getSettings();

  const referrals = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      createdAt: users.createdAt,
      approvedCount: sql<number>`coalesce((
        select count(*) from gmail_submissions g
        where g.user_id = users.id and g.status = 'APPROVED'
      ), 0)`,
    })
    .from(users)
    .where(eq(users.referredBy, user.referralCode))
    .orderBy(desc(users.createdAt))
    .limit(100);

  const totalBonus = referrals.reduce(
    (sum, r) => sum + Number(r.approvedCount) * settings.referralBonus,
    0
  );

  const bonusHistory = await db
    .select({
      email: gmailSubmissions.accountEmail,
      price: gmailSubmissions.price,
      createdAt: gmailSubmissions.reviewedAt,
      userName: users.name,
    })
    .from(gmailSubmissions)
    .innerJoin(users, eq(gmailSubmissions.userId, users.id))
    .where(
      eq(users.referredBy, user.referralCode) &&
        eq(gmailSubmissions.status, "APPROVED")
    )
    .orderBy(desc(gmailSubmissions.reviewedAt))
    .limit(50);

  const shareUrl = `${process.env.NEXT_PUBLIC_SITE_URL ?? "https://zero99gmail.com"}/auth?ref=${user.referralCode}`;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Referral
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Ajak teman, dapatkan bonus untuk setiap Gmail yang mereka setorkan.
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard
          icon={<Users className="h-5 w-5" />}
          label="Total Referral"
          value={formatNumber(referrals.length)}
          sub="Member yang bergabung"
          accent="rose"
        />
        <StatCard
          icon={<TrendingUp className="h-5 w-5" />}
          label="Total Bonus"
          value={formatIDR(totalBonus)}
          sub="Dari referral disetujui"
          accent="emerald"
        />
        <StatCard
          icon={<Gift className="h-5 w-5" />}
          label="Bonus / Gmail"
          value={formatIDR(settings.referralBonus)}
          sub="Per Gmail disetujui"
          accent="amber"
        />
      </div>

      {/* Share */}
      <Card className="relative overflow-hidden">
        <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-rose-500/10 blur-2xl" />
        <div className="relative p-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-rose-500/10 text-rose-400">
              <Link2 className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-display text-base font-semibold text-white">
                Link Referral Anda
              </h3>
              <p className="text-xs text-slate-500">
                Bagikan link ini ke teman Anda
              </p>
            </div>
          </div>
          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <div className="flex-1 rounded-xl border border-slate-700 bg-slate-950/60 px-4 py-3">
              <p className="truncate font-mono text-xs text-slate-300">
                {shareUrl}
              </p>
            </div>
            <CopyButton text={shareUrl} label="Salin Link" className="h-11 px-4" />
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Badge variant="rose">
              <Gift className="h-3 w-3" />
              Kode: {user.referralCode}
            </Badge>
            <CopyButton text={user.referralCode} label="Salin Kode" />
          </div>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Referrals */}
        <Card>
          <CardHeader
            title="Referral Anda"
            subtitle={`${referrals.length} member`}
          />
          {referrals.length === 0 ? (
            <EmptyState
              icon={<Users className="h-6 w-6" />}
              title="Belum ada referral"
              description="Bagikan link Anda untuk mulai mendapat bonus."
            />
          ) : (
            <div className="divide-y divide-slate-800">
              {referrals.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between gap-4 px-5 py-3.5"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-slate-200">
                      {r.name}
                    </p>
                    <p className="truncate text-xs text-slate-500">
                      {r.email}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-emerald-400">
                      {formatNumber(Number(r.approvedCount))} Gmail
                    </p>
                    <p className="text-xs text-slate-500">
                      {formatDateTime(r.createdAt)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Bonus history */}
        <Card>
          <CardHeader
            title="Riwayat Bonus"
            subtitle="Bonus dari referral yang disetujui"
          />
          {bonusHistory.length === 0 ? (
            <EmptyState
              icon={<CheckCircle2 className="h-6 w-6" />}
              title="Belum ada bonus"
              description="Bonus akan muncul saat referral Anda disetujui."
            />
          ) : (
            <div className="divide-y divide-slate-800">
              {bonusHistory.map((b, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between gap-4 px-5 py-3.5"
                >
                  <div className="min-w-0">
                    <p className="truncate font-mono text-xs text-slate-200">
                      {b.email}
                    </p>
                    <p className="text-xs text-slate-500">
                      dari {b.userName}
                    </p>
                  </div>
                  <span className="text-sm font-semibold text-emerald-400">
                    +{formatIDR(settings.referralBonus)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
