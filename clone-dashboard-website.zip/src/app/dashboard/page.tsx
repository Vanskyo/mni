import { db } from "@/db";
import { gmailSubmissions, users, withdrawals, announcements } from "@/db/schema";
import { eq, desc, sql, and } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { formatIDR, formatNumber, formatDateTime, timeAgo } from "@/lib/utils";
import {
  Card,
  CardHeader,
  StatCard,
  StatusBadge,
  Badge,
  EmptyState,
  CopyButton,
} from "@/components/ui";
import {
  Wallet,
  Send,
  CheckCircle2,
  Clock,
  Megaphone,
  History,
  ArrowRight,
  Gift,
  Mail,
} from "lucide-react";
import Link from "next/link";

export default async function DashboardPage() {
  const user = await requireUser();
  const settings = await getSettings();

  const [stats, recent, latestAnnouncement] = await Promise.all([
    db
      .select({
        total: sql<number>`count(*)`,
        approved: sql<number>`sum(case when status = 'APPROVED' then 1 else 0 end)`,
        pending: sql<number>`sum(case when status = 'PENDING' then 1 else 0 end)`,
        rejected: sql<number>`sum(case when status = 'REJECTED' then 1 else 0 end)`,
      })
      .from(gmailSubmissions)
      .where(eq(gmailSubmissions.userId, user.id)),
    db
      .select()
      .from(gmailSubmissions)
      .where(eq(gmailSubmissions.userId, user.id))
      .orderBy(desc(gmailSubmissions.createdAt))
      .limit(5),
    db
      .select()
      .from(announcements)
      .orderBy(desc(announcements.createdAt))
      .limit(1),
  ]);

  const s = stats[0] ?? { total: 0, approved: 0, pending: 0, rejected: 0 };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Halo, {user.name.split(" ")[0]} 👋
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Selamat datang di dashboard setoran Gmail Anda.
          </p>
        </div>
        <Link href="/dashboard/setoran">
          <button className="inline-flex h-11 items-center gap-2 rounded-xl bg-gradient-to-r from-rose-500 to-red-500 px-5 text-sm font-semibold text-white shadow-lg shadow-rose-500/25 transition hover:brightness-110 cursor-pointer">
            <Send className="h-4 w-4" />
            Setor Gmail
          </button>
        </Link>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={<Wallet className="h-5 w-5" />}
          label="Saldo"
          value={formatIDR(user.balance)}
          sub="Siap ditarik"
          accent="emerald"
        />
        <StatCard
          icon={<Mail className="h-5 w-5" />}
          label="Total Disetor"
          value={formatNumber(Number(s.total))}
          sub={`${formatNumber(Number(s.rejected))} ditolak`}
          accent="rose"
        />
        <StatCard
          icon={<CheckCircle2 className="h-5 w-5" />}
          label="Disetujui"
          value={formatNumber(Number(s.approved))}
          sub={`${formatIDR(Number(s.approved) * settings.pricePerGmail)} diterima`}
          accent="sky"
        />
        <StatCard
          icon={<Clock className="h-5 w-5" />}
          label="Pending"
          value={formatNumber(Number(s.pending))}
          sub="Menunggu verifikasi"
          accent="amber"
        />
      </div>

      {/* Announcement */}
      {latestAnnouncement[0] && (
        <Card className="relative overflow-hidden border-rose-500/20">
          <div className="absolute left-0 top-0 h-full w-1 bg-gradient-to-b from-rose-500 to-red-500" />
          <div className="flex items-start gap-4 p-5">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-500/10 text-rose-400">
              <Megaphone className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-wider text-rose-400">
                Pengumuman
              </p>
              <h3 className="mt-1 font-display text-sm font-semibold text-white">
                {latestAnnouncement[0].title}
              </h3>
              <p className="mt-1 line-clamp-2 text-sm text-slate-400">
                {latestAnnouncement[0].content}
              </p>
            </div>
          </div>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Recent submissions */}
        <Card className="lg:col-span-2">
          <CardHeader
            title="Setoran Terbaru"
            subtitle="5 setoran Gmail terakhir Anda"
            action={
              <Link
                href="/dashboard/riwayat"
                className="inline-flex items-center gap-1 text-xs font-semibold text-rose-400 hover:text-rose-300"
              >
                Lihat Semua
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            }
          />
          {recent.length === 0 ? (
            <EmptyState
              icon={<History className="h-6 w-6" />}
              title="Belum ada setoran"
              description="Mulai setorkan Gmail Anda untuk mendapatkan penghasilan."
              action={
                <Link href="/dashboard/setoran">
                  <button className="inline-flex h-9 items-center gap-2 rounded-xl bg-gradient-to-r from-rose-500 to-red-500 px-4 text-xs font-semibold text-white cursor-pointer">
                    <Send className="h-3.5 w-3.5" />
                    Setor Sekarang
                  </button>
                </Link>
              }
            />
          ) : (
            <div className="divide-y divide-slate-800">
              {recent.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between gap-4 px-5 py-3.5"
                >
                  <div className="min-w-0">
                    <p className="truncate font-mono text-sm text-slate-200">
                      {r.accountEmail}
                    </p>
                    <p className="text-xs text-slate-500">
                      {timeAgo(r.createdAt)}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-emerald-400">
                      +{formatIDR(r.price)}
                    </span>
                    <StatusBadge status={r.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Quick actions */}
        <div className="space-y-4">
          <Card className="p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-500/10 text-rose-400">
                <Gift className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">
                  Bonus Referral
                </p>
                <p className="text-xs text-slate-500">
                  {formatIDR(settings.referralBonus)} / Gmail disetujui
                </p>
              </div>
            </div>
            <Link href="/dashboard/referral">
              <button className="mt-4 w-full rounded-xl border border-slate-700 py-2.5 text-xs font-semibold text-slate-300 transition hover:bg-slate-800 cursor-pointer">
                Ajak Teman
              </button>
            </Link>
          </Card>

          <Card className="p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400">
                <Wallet className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">
                  Tarik Saldo
                </p>
                <p className="text-xs text-slate-500">
                  Min. {formatIDR(settings.minWithdrawal)}
                </p>
              </div>
            </div>
            <Link href="/dashboard/tarik-saldo">
              <button className="mt-4 w-full rounded-xl border border-slate-700 py-2.5 text-xs font-semibold text-slate-300 transition hover:bg-slate-800 cursor-pointer">
                Tarik Sekarang
              </button>
            </Link>
          </Card>

          <Card className="p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">
                  Rate Saat Ini
                </p>
                <p className="text-xs text-slate-500">
                  1 Gmail = {formatIDR(settings.pricePerGmail)}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
