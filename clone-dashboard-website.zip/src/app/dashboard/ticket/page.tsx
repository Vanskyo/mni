"use client";

import { useEffect, useState } from "react";
import {
  Ticket,
  Send,
  MessageSquare,
  Clock,
  CheckCircle2,
  Loader2,
} from "lucide-react";
import {
  Card,
  CardHeader,
  Button,
  Input,
  Textarea,
  Select,
  Field,
  StatusBadge,
  EmptyState,
  Badge,
  useToast,
} from "@/components/ui";
import { formatDateTime } from "@/lib/utils";

interface TicketType {
  id: number;
  subject: string;
  category: string;
  message: string;
  status: string;
  createdAt: string;
  replies: Array<{
    id: number;
    message: string;
    createdAt: string;
  }>;
}

const CATEGORIES = [
  "Setoran Bermasalah",
  "Penarikan Bermasalah",
  "Akun & Login",
  "Referral",
  "Lainnya",
];

export default function TicketPage() {
  const { toast } = useToast();
  const [tickets, setTickets] = useState<TicketType[]>([]);
  const [loading, setLoading] = useState(true);
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    try {
      const res = await fetch("/api/tickets");
      const data = await res.json();
      setTickets(data.tickets ?? []);
    } catch {
      toast("Gagal memuat tiket", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject, category, message }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Gagal membuat tiket", "error");
        return;
      }
      toast("Tiket berhasil dibuat!");
      setSubject("");
      setMessage("");
      load();
    } catch {
      toast("Terjadi kesalahan jaringan", "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Tiket Bantuan
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Sampaikan masalah Anda ke tim admin.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Form */}
        <Card>
          <CardHeader
            title="Buat Tiket Baru"
            subtitle="Admin akan merespons dalam 1-24 jam"
          />
          <form onSubmit={submit} className="space-y-4 p-5">
            <Field label="Kategori">
              <Select value={category} onChange={(e) => setCategory(e.target.value)}>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Subjek">
              <Input
                placeholder="Contoh: Setoran belum disetujui"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
            </Field>

            <Field label="Pesan">
              <Textarea
                placeholder="Jelaskan masalah Anda secara detail..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
              />
            </Field>

            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              Kirim Tiket
            </Button>
          </form>
        </Card>

        {/* List */}
        <Card>
          <CardHeader
            title="Tiket Anda"
            subtitle={`${tickets.length} tiket`}
          />
          {loading ? (
            <div className="flex items-center justify-center py-14">
              <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
            </div>
          ) : tickets.length === 0 ? (
            <EmptyState
              icon={<Ticket className="h-6 w-6" />}
              title="Belum ada tiket"
              description="Buat tiket jika ada masalah yang perlu dibantu."
            />
          ) : (
            <div className="space-y-4 p-5">
              {tickets.map((t) => (
                <div
                  key={t.id}
                  className="rounded-xl border border-slate-800 bg-slate-950/60 p-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-white">
                        {t.subject}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-500">
                        {formatDateTime(t.createdAt)}
                      </p>
                    </div>
                    <StatusBadge status={t.status} />
                  </div>
                  <p className="mt-3 text-sm text-slate-400">
                    {t.message}
                  </p>
                  {t.replies.length > 0 && (
                    <div className="mt-4 space-y-2 border-t border-slate-800 pt-3">
                      {t.replies.map((r) => (
                        <div
                          key={r.id}
                          className="rounded-lg bg-slate-900/80 p-3"
                        >
                          <div className="flex items-center gap-2 text-xs">
                            <Badge variant="rose">Admin</Badge>
                            <span className="text-slate-500">
                              {formatDateTime(r.createdAt)}
                            </span>
                          </div>
                          <p className="mt-2 text-xs text-slate-300">
                            {r.message}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
