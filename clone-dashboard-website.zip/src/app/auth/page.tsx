"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  Mail,
  Lock,
  User,
  Gift,
  ArrowRight,
  Eye,
  EyeOff,
  ShieldCheck,
  Zap,
  Wallet,
} from "lucide-react";
import { Button, Input, Field, useToast } from "@/components/ui";

export default function AuthPage() {
  return (
    <Suspense fallback={<AuthFallback />}>
      <AuthContent />
    </Suspense>
  );
}

function AuthFallback() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-700 border-t-rose-500" />
    </div>
  );
}

function AuthContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();

  const [mode, setMode] = useState<"login" | "register">("login");
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    referralCode: "",
  });

  useEffect(() => {
    const ref = searchParams.get("ref");
    if (ref) {
      setForm((f) => ({ ...f, referralCode: ref.toUpperCase() }));
      setMode("register");
    }
  }, [searchParams]);

  const set = (k: string, v: string) =>
    setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "Terjadi kesalahan", "error");
        return;
      }
      toast(
        mode === "login" ? "Selamat datang kembali!" : "Pendaftaran berhasil!"
      );
      router.push("/dashboard");
      router.refresh();
    } catch {
      toast("Terjadi kesalahan jaringan", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-950">
      {/* Left branding */}
      <div className="relative hidden w-1/2 overflow-hidden lg:block">
        <div className="grid-bg absolute inset-0" />
        <div className="absolute left-1/2 top-1/3 -translate-x-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-rose-500/20 blur-[120px]" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-red-600 shadow-lg shadow-rose-500/30">
              <Mail className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="font-display text-base font-bold leading-tight">
                S3L GMAIL
              </p>
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-rose-400">
                Zero99
              </p>
            </div>
          </div>

          <div className="max-w-md">
            <h1 className="font-display text-4xl font-bold leading-tight">
              Cuan dari{" "}
              <span className="bg-gradient-to-r from-rose-400 to-red-400 bg-clip-text text-transparent">
                Setoran Gmail
              </span>
            </h1>
            <p className="mt-4 text-sm leading-relaxed text-slate-400">
              Platform setoran daftar Gmail dengan sistem otomatis, pembayaran
              saldo instan, dan pengelolaan admin lengkap.
            </p>
            <div className="mt-8 space-y-4">
              {[
                { icon: Zap, text: "Pembayaran saldo instan setelah disetujui" },
                { icon: ShieldCheck, text: "Data akun terenkripsi & aman" },
                { icon: Wallet, text: "Penarikan 1-2 menit ke DANA/GoPay/OVO/BCA" },
              ].map((f) => (
                <div key={f.text} className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-rose-500/20 bg-rose-500/10 text-rose-400">
                    <f.icon className="h-4 w-4" />
                  </div>
                  <span className="text-sm text-slate-300">{f.text}</span>
                </div>
              ))}
            </div>
          </div>

          <p className="text-xs text-slate-600">
            © 2026 S3L GMAIL ZERO99
          </p>
        </div>
      </div>

      {/* Right form */}
      <div className="flex w-full items-center justify-center p-6 lg:w-1/2">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center gap-2.5 lg:hidden">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-red-600">
              <Mail className="h-4.5 w-4.5 text-white" />
            </div>
            <span className="font-display text-sm font-bold">
              S3L GMAIL <span className="text-rose-400">ZERO99</span>
            </span>
          </div>

          <div className="mb-8">
            <h2 className="font-display text-2xl font-bold text-white">
              {mode === "login" ? "Selamat datang kembali" : "Buat akun baru"}
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              {mode === "login"
                ? "Masuk untuk mengakses dashboard Anda"
                : "Daftar gratis, mulai setoran Gmail hari ini"}
            </p>
          </div>

          {/* Tabs */}
          <div className="mb-6 grid grid-cols-2 gap-1 rounded-xl border border-slate-800 bg-slate-900/60 p-1">
            {(["login", "register"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`h-10 rounded-lg text-sm font-semibold transition cursor-pointer ${
                  mode === m
                    ? "bg-gradient-to-r from-rose-500 to-red-500 text-white shadow-lg shadow-rose-500/25"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {m === "login" ? "Masuk" : "Daftar"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === "register" && (
              <Field label="Nama Lengkap">
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                  <Input
                    className="pl-10"
                    placeholder="Nama Anda"
                    value={form.name}
                    onChange={(e) => set("name", e.target.value)}
                    required
                  />
                </div>
              </Field>
            )}

            <Field label="Email">
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <Input
                  className="pl-10"
                  type="email"
                  placeholder="nama@email.com"
                  value={form.email}
                  onChange={(e) => set("email", e.target.value)}
                  required
                />
              </div>
            </Field>

            <Field label="Password">
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <Input
                  className="pl-10 pr-10"
                  type={showPw ? "text" : "password"}
                  placeholder="••••••••"
                  value={form.password}
                  onChange={(e) => set("password", e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 transition hover:text-white cursor-pointer"
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {mode === "register" && (
                <span className="block text-xs text-slate-500">
                  Minimal 6 karakter
                </span>
              )}
            </Field>

            {mode === "register" && (
              <Field label="Kode Referral" hint="Opsional — punya kode? masukkan untuk bonus">
                <div className="relative">
                  <Gift className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                  <Input
                    className="pl-10 uppercase"
                    placeholder="ABC123"
                    value={form.referralCode}
                    onChange={(e) => set("referralCode", e.target.value)}
                  />
                </div>
              </Field>
            )}

            <Button type="submit" size="lg" className="w-full" disabled={loading}>
              {loading
                ? "Memproses..."
                : mode === "login"
                ? "Masuk ke Dashboard"
                : "Daftar & Mulai Cuan"}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-500">
            {mode === "login" ? (
              <>
                Belum punya akun?{" "}
                <button
                  onClick={() => setMode("register")}
                  className="font-semibold text-rose-400 hover:text-rose-300 cursor-pointer"
                >
                  Daftar di sini
                </button>
              </>
            ) : (
              <>
                Sudah punya akun?{" "}
                <button
                  onClick={() => setMode("login")}
                  className="font-semibold text-rose-400 hover:text-rose-300 cursor-pointer"
                >
                  Masuk di sini
                </button>
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}
