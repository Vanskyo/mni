import { NextResponse } from "next/server";
import { db } from "@/db";
import { withdrawals, users } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export async function GET(req: Request) {
  await requireAdmin();
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status") ?? "ALL";

  const conditions =
    status === "ALL" ? undefined : eq(withdrawals.status, status);

  const list = await db
    .select({
      id: withdrawals.id,
      method: withdrawals.method,
      accountName: withdrawals.accountName,
      accountNumber: withdrawals.accountNumber,
      amount: withdrawals.amount,
      fee: withdrawals.fee,
      status: withdrawals.status,
      adminNote: withdrawals.adminNote,
      createdAt: withdrawals.createdAt,
      reviewedAt: withdrawals.reviewedAt,
      userName: users.name,
      userEmail: users.email,
    })
    .from(withdrawals)
    .innerJoin(users, eq(withdrawals.userId, users.id))
    .where(conditions)
    .orderBy(desc(withdrawals.createdAt))
    .limit(200);

  return NextResponse.json({ withdrawals: list });
}

export async function PATCH(req: Request) {
  await requireAdmin();
  try {
    const body = await req.json();
    const id = Number(body.id);
    const action = String(body.action ?? ""); // APPROVE | REJECT
    const note = String(body.note ?? "").trim();

    const target = await db
      .select()
      .from(withdrawals)
      .where(eq(withdrawals.id, id))
      .limit(1);
    const wd = target[0];
    if (!wd) {
      return NextResponse.json(
        { error: "Penarikan tidak ditemukan" },
        { status: 404 }
      );
    }
    if (wd.status !== "PENDING") {
      return NextResponse.json(
        { error: "Penarikan sudah diproses" },
        { status: 400 }
      );
    }

    if (action === "APPROVE") {
      await db
        .update(withdrawals)
        .set({ status: "APPROVED", reviewedAt: new Date() })
        .where(eq(withdrawals.id, id));
      return NextResponse.json({ success: true, action: "APPROVED" });
    }

    if (action === "REJECT") {
      // Refund balance
      await db
        .update(users)
        .set({ balance: sql`${users.balance} + ${wd.amount} + ${wd.fee}` })
        .where(eq(users.id, wd.userId));

      await db
        .update(withdrawals)
        .set({
          status: "REJECTED",
          adminNote: note || "Ditolak oleh admin",
          reviewedAt: new Date(),
        })
        .where(eq(withdrawals.id, id));
      return NextResponse.json({ success: true, action: "REJECTED" });
    }

    return NextResponse.json({ error: "Aksi tidak valid" }, { status: 400 });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
