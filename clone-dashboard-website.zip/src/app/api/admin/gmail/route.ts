import { NextResponse } from "next/server";
import { db } from "@/db";
import { gmailSubmissions, users } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export async function GET(req: Request) {
  await requireAdmin();
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status") ?? "ALL";

  const conditions =
    status === "ALL" ? undefined : eq(gmailSubmissions.status, status);

  const list = await db
    .select({
      id: gmailSubmissions.id,
      accountEmail: gmailSubmissions.accountEmail,
      accountPassword: gmailSubmissions.accountPassword,
      recoveryPhone: gmailSubmissions.recoveryPhone,
      status: gmailSubmissions.status,
      price: gmailSubmissions.price,
      adminNote: gmailSubmissions.adminNote,
      createdAt: gmailSubmissions.createdAt,
      reviewedAt: gmailSubmissions.reviewedAt,
      userName: users.name,
      userEmail: users.email,
      referralCode: users.referralCode,
    })
    .from(gmailSubmissions)
    .innerJoin(users, eq(gmailSubmissions.userId, users.id))
    .where(conditions)
    .orderBy(desc(gmailSubmissions.createdAt))
    .limit(200);

  return NextResponse.json({ submissions: list });
}

export async function PATCH(req: Request) {
  const admin = await requireAdmin();
  try {
    const body = await req.json();
    const id = Number(body.id);
    const action = String(body.action ?? ""); // APPROVE | REJECT
    const note = String(body.note ?? "").trim();

    const target = await db
      .select()
      .from(gmailSubmissions)
      .where(eq(gmailSubmissions.id, id))
      .limit(1);
    const submission = target[0];
    if (!submission) {
      return NextResponse.json(
        { error: "Setoran tidak ditemukan" },
        { status: 404 }
      );
    }
    if (submission.status !== "PENDING") {
      return NextResponse.json(
        { error: "Setoran sudah diproses" },
        { status: 400 }
      );
    }

    const settings = await getSettings();

    if (action === "APPROVE") {
      await db
        .update(gmailSubmissions)
        .set({ status: "APPROVED", reviewedAt: new Date() })
        .where(eq(gmailSubmissions.id, id));

      // Credit user
      await db
        .update(users)
        .set({
          balance: sql`${users.balance} + ${submission.price}`,
          totalEarned: sql`${users.totalEarned} + ${submission.price}`,
        })
        .where(eq(users.id, submission.userId));

      // Referral bonus
      const owner = await db
        .select({ referredBy: users.referredBy })
        .from(users)
        .where(eq(users.id, submission.userId))
        .limit(1);
      const referrerCode = owner[0]?.referredBy;
      if (referrerCode && settings.referralBonus > 0) {
        const referrer = await db
          .select()
          .from(users)
          .where(eq(users.referralCode, referrerCode))
          .limit(1);
        if (referrer[0]) {
          await db
            .update(users)
            .set({
              balance: sql`${users.balance} + ${settings.referralBonus}`,
              totalEarned: sql`${users.totalEarned} + ${settings.referralBonus}`,
            })
            .where(eq(users.id, referrer[0].id));
        }
      }

      return NextResponse.json({ success: true, action: "APPROVED" });
    }

    if (action === "REJECT") {
      await db
        .update(gmailSubmissions)
        .set({
          status: "REJECTED",
          adminNote: note || "Tidak memenuhi syarat",
          reviewedAt: new Date(),
        })
        .where(eq(gmailSubmissions.id, id));
      return NextResponse.json({ success: true, action: "REJECTED" });
    }

    return NextResponse.json({ error: "Aksi tidak valid" }, { status: 400 });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
