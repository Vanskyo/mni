import { NextResponse } from "next/server";
import { db } from "@/db";
import { announcements } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export async function GET() {
  const list = await db
    .select()
    .from(announcements)
    .orderBy(desc(announcements.createdAt))
    .limit(50);
  return NextResponse.json({ announcements: list });
}

export async function POST(req: Request) {
  await requireAdmin();
  try {
    const body = await req.json();
    const title = String(body.title ?? "").trim();
    const content = String(body.content ?? "").trim();

    if (!title || title.length < 5) {
      return NextResponse.json(
        { error: "Judul minimal 5 karakter" },
        { status: 400 }
      );
    }
    if (content.length < 10) {
      return NextResponse.json(
        { error: "Konten minimal 10 karakter" },
        { status: 400 }
      );
    }

    const result = await db
      .insert(announcements)
      .values({ title, content })
      .returning();

    return NextResponse.json({ announcement: result[0] });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  await requireAdmin();
  try {
    const { searchParams } = new URL(req.url);
    const id = Number(searchParams.get("id"));
    const result = await db
      .delete(announcements)
      .where(eq(announcements.id, id))
      .returning();
    if (!result[0]) {
      return NextResponse.json(
        { error: "Pengumuman tidak ditemukan" },
        { status: 404 }
      );
    }
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
