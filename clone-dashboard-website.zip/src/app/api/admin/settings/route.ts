import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { getSettings, setSetting } from "@/lib/settings";

export async function GET() {
  await requireAdmin();
  const settings = await getSettings();
  return NextResponse.json({ settings });
}

export async function PUT(req: Request) {
  await requireAdmin();
  try {
    const body = await req.json();
    await setSetting("pricePerGmail", String(Math.floor(Number(body.pricePerGmail) || 4700)));
    await setSetting("minWithdrawal", String(Math.floor(Number(body.minWithdrawal) || 25000)));
    await setSetting("referralBonus", String(Math.floor(Number(body.referralBonus) || 500)));
    await setSetting("withdrawalFee", String(Math.floor(Number(body.withdrawalFee) || 1500)));
    await setSetting("siteName", String(body.siteName || "S3L GMAIL ZERO99"));
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
