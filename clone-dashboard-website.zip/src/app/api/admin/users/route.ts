import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, gmailSubmissions } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export async function GET() {
  await requireAdmin();

  const list = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      referralCode: users.referralCode,
      referredBy: users.referredBy,
      balance: users.balance,
      totalEarned: users.totalEarned,
      role: users.role,
      createdAt: users.createdAt,
      submissionCount: sql<number>`coalesce((
        select count(*) from gmail_submissions g
        where g.user_id = users.id
      ), 0)`,
    })
    .from(users)
    .orderBy(desc(users.createdAt))
    .limit(200);

  return NextResponse.json({ users: list });
}

export async function PATCH(req: Request) {
  await requireAdmin();
  try {
    const body = await req.json();
    const id = Number(body.id);
    const balance = Math.floor(Number(body.balance ?? NaN));

    if (Number.isNaN(balance) || balance < 0) {
      return NextResponse.json(
        { error: "Saldo tidak valid" },
        { status: 400 }
      );
    }

    const result = await db
      .update(users)
      .set({ balance })
      .where(eq(users.id, id))
      .returning();

    if (!result[0]) {
      return NextResponse.json(
        { error: "Pengguna tidak ditemukan" },
        { status: 404 }
      );
    }
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
