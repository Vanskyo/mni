import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";

export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return NextResponse.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      balance: user.balance,
      totalEarned: user.totalEarned,
      role: user.role,
      referralCode: user.referralCode,
      referredBy: user.referredBy,
      createdAt: user.createdAt,
    },
  });
}
