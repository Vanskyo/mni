import { NextResponse } from "next/server";
import { db } from "@/db";
import { gmailSubmissions } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const result = await db
    .delete(gmailSubmissions)
    .where(
      and(
        eq(gmailSubmissions.id, Number(id)),
        eq(gmailSubmissions.userId, user.id),
        eq(gmailSubmissions.status, "PENDING")
      )
    )
    .returning();

  if (!result[0]) {
    return NextResponse.json(
      { error: "Setoran tidak ditemukan atau sudah diproses" },
      { status: 404 }
    );
  }
  return NextResponse.json({ success: true });
}
