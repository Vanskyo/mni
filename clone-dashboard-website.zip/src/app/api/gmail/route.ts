import { NextResponse } from "next/server";
import { db } from "@/db";
import { gmailSubmissions, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const list = await db
    .select()
    .from(gmailSubmissions)
    .where(eq(gmailSubmissions.userId, user.id))
    .orderBy(desc(gmailSubmissions.createdAt))
    .limit(100);

  return NextResponse.json({ submissions: list });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json();
    const items: Array<{ email: string; password: string; phone?: string }> =
      body.items ?? [];

    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: "Tambahkan minimal 1 akun Gmail" },
        { status: 400 }
      );
    }
    if (items.length > 20) {
      return NextResponse.json(
        { error: "Maksimal 20 akun per pengiriman" },
        { status: 400 }
      );
    }

    const settings = await getSettings();
    const seen = new Set<string>();

    for (const item of items) {
      const email = String(item.email ?? "").trim().toLowerCase();
      const password = String(item.password ?? "").trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return NextResponse.json(
          { error: `Email tidak valid: ${email || "(kosong)"}` },
          { status: 400 }
        );
      }
      if (password.length < 6) {
        return NextResponse.json(
          { error: `Password minimal 6 karakter untuk ${email}` },
          { status: 400 }
        );
      }
      if (seen.has(email)) {
        return NextResponse.json(
          { error: `Email ${email} duplikat` },
          { status: 400 }
        );
      }
      seen.add(email);
    }

    const existing = await db
      .select({ email: gmailSubmissions.accountEmail })
      .from(gmailSubmissions)
      .where(eq(gmailSubmissions.userId, user.id));
    const existingEmails = new Set(existing.map((e) => e.email));
    const dup = [...seen].find((e) => existingEmails.has(e));
    if (dup) {
      return NextResponse.json(
        { error: `Email ${dup} sudah pernah disetorkan` },
        { status: 409 }
      );
    }

    const values = items.map((item) => ({
      userId: user.id,
      accountEmail: String(item.email).trim().toLowerCase(),
      accountPassword: String(item.password),
      recoveryPhone: item.phone ? String(item.phone).trim() : null,
      status: "PENDING",
      price: settings.pricePerGmail,
    }));

    await db.insert(gmailSubmissions).values(values);

    return NextResponse.json({
      success: true,
      count: values.length,
      total: values.length * settings.pricePerGmail,
    });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
