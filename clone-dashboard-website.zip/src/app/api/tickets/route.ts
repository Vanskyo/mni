import { NextResponse } from "next/server";
import { db } from "@/db";
import { tickets, ticketReplies } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const list = await db
    .select({
      ticket: tickets,
      replies: ticketReplies,
    })
    .from(tickets)
    .leftJoin(ticketReplies, eq(ticketReplies.ticketId, tickets.id))
    .where(eq(tickets.userId, user.id))
    .orderBy(desc(tickets.createdAt), ticketReplies.createdAt)
    .limit(100);

  const grouped = new Map<number, any>();
  for (const row of list) {
    if (!grouped.has(row.ticket.id)) {
      grouped.set(row.ticket.id, { ...row.ticket, replies: [] });
    }
    if (row.replies) {
      grouped.get(row.ticket.id).replies.push(row.replies);
    }
  }

  return NextResponse.json({ tickets: [...grouped.values()] });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json();
    const subject = String(body.subject ?? "").trim();
    const category = String(body.category ?? "Umum");
    const message = String(body.message ?? "").trim();

    if (!subject || subject.length < 5) {
      return NextResponse.json(
        { error: "Subjek minimal 5 karakter" },
        { status: 400 }
      );
    }
    if (message.length < 10) {
      return NextResponse.json(
        { error: "Pesan minimal 10 karakter" },
        { status: 400 }
      );
    }

    const result = await db
      .insert(tickets)
      .values({ userId: user.id, subject, category, message, status: "OPEN" })
      .returning();

    return NextResponse.json({ ticket: result[0] });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
