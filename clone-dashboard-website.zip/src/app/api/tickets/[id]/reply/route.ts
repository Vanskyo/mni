import { NextResponse } from "next/server";
import { db } from "@/db";
import { tickets, ticketReplies, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const body = await req.json();
  const message = String(body.message ?? "").trim();

  if (message.length < 5) {
    return NextResponse.json(
      { error: "Balasan minimal 5 karakter" },
      { status: 400 }
    );
  }

  const ticket = await db
    .select()
    .from(tickets)
    .where(eq(tickets.id, Number(id)))
    .limit(1);

  if (!ticket[0]) {
    return NextResponse.json({ error: "Tiket tidak ditemukan" }, { status: 404 });
  }
  if (ticket[0].userId !== user.id) {
    return NextResponse.json({ error: "Bukan tiket Anda" }, { status: 403 });
  }

  await db.insert(ticketReplies).values({
    ticketId: ticket[0].id,
    adminId: user.id,
    message,
  });

  return NextResponse.json({ success: true });
}
