import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, gmailSubmissions } from "@/db/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const settings = await getSettings();

  const referrals = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      createdAt: users.createdAt,
      approvedCount: sql<number>`coalesce((
        select count(*) from gmail_submissions g
        where g.user_id = users.id and g.status = 'APPROVED'
      ), 0)`,
    })
    .from(users)
    .where(eq(users.referredBy, user.referralCode))
    .orderBy(desc(users.createdAt))
    .limit(100);

  const totalBonus = referrals.reduce(
    (sum, r) => sum + Number(r.approvedCount) * settings.referralBonus,
    0
  );

  // Bonus history from approved submissions of referrals
  const bonusHistory = await db
    .select({
      email: gmailSubmissions.accountEmail,
      price: gmailSubmissions.price,
      createdAt: gmailSubmissions.reviewedAt,
      userName: users.name,
    })
    .from(gmailSubmissions)
    .innerJoin(users, eq(gmailSubmissions.userId, users.id))
    .where(
      and(
        eq(users.referredBy, user.referralCode),
        eq(gmailSubmissions.status, "APPROVED")
      )
    )
    .orderBy(desc(gmailSubmissions.reviewedAt))
    .limit(50);

  return NextResponse.json({
    referrals,
    totalBonus,
    bonusHistory,
    bonusPerGmail: settings.referralBonus,
  });
}
