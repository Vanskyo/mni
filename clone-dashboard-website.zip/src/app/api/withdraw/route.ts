import { NextResponse } from "next/server";
import { db } from "@/db";
import { withdrawals, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const list = await db
    .select()
    .from(withdrawals)
    .where(eq(withdrawals.userId, user.id))
    .orderBy(desc(withdrawals.createdAt))
    .limit(50);

  return NextResponse.json({ withdrawals: list });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json();
    const method = String(body.method ?? "");
    const accountName = String(body.accountName ?? "").trim();
    const accountNumber = String(body.accountNumber ?? "").trim();
    const amount = Math.floor(Number(body.amount ?? 0));

    const settings = await getSettings();

    if (!["DANA", "GOPAY", "OVO", "BCA"].includes(method)) {
      return NextResponse.json(
        { error: "Metode penarikan tidak valid" },
        { status: 400 }
      );
    }
    if (!accountName) {
      return NextResponse.json(
        { error: "Nama pemilik rekening wajib diisi" },
        { status: 400 }
      );
    }
    if (!/^[0-9]{8,16}$/.test(accountNumber.replace(/\s/g, ""))) {
      return NextResponse.json(
        { error: "Nomor rekening/dompet tidak valid (8-16 digit)" },
        { status: 400 }
      );
    }
    if (amount < settings.minWithdrawal) {
      return NextResponse.json(
        { error: `Minimal penarikan ${settings.minWithdrawal.toLocaleString("id-ID")}` },
        { status: 400 }
      );
    }
    if (amount > user.balance) {
      return NextResponse.json(
        { error: "Saldo tidak mencukupi" },
        { status: 400 }
      );
    }

    const fee = settings.withdrawalFee;
    const netAmount = amount - fee;

    // Deduct balance immediately (hold)
    await db
      .update(users)
      .set({ balance: user.balance - amount })
      .where(eq(users.id, user.id));

    await db.insert(withdrawals).values({
      userId: user.id,
      method,
      accountName,
      accountNumber: accountNumber.replace(/\s/g, ""),
      amount: netAmount,
      fee,
      status: "PENDING",
    });

    return NextResponse.json({
      success: true,
      amount: netAmount,
      fee,
    });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
