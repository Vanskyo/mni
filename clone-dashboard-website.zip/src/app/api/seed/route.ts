import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, announcements, settings } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { hashPassword, makeSalt } from "@/lib/auth";
import { generateReferralCode } from "@/lib/utils";

// Self-seeding endpoint: only runs when there is no admin user yet.
export async function GET() {
  const adminCheck = await db
    .select()
    .from(users)
    .where(eq(users.role, "admin"))
    .limit(1);

  if (adminCheck[0]) {
    return NextResponse.json({ seeded: false, reason: "already seeded" });
  }

  const salt = makeSalt();
  await db.insert(users).values({
    name: "Admin Zero99",
    email: "admin@zero99.com",
    password: hashPassword("admin123", salt),
    salt,
    referralCode: "ADMIN99",
    balance: 0,
    role: "admin",
  });

  const defaultSettings: Array<[string, string]> = [
    ["siteName", "S3L GMAIL ZERO99"],
    ["pricePerGmail", "4700"],
    ["minWithdrawal", "25000"],
    ["referralBonus", "500"],
    ["withdrawalFee", "1500"],
  ];
  for (const [key, value] of defaultSettings) {
    await db
      .insert(settings)
      .values({ key, value })
      .onConflictDoUpdate({ target: settings.key, set: { value } });
  }

  await db.insert(announcements).values([
    {
      title: "Selamat datang di S3L GMAIL ZERO99!",
      content:
        "Platform setoran Gmail resmi telah dibuka. Setiap Gmail yang disetorkan dan disetujui akan langsung ditambahkan ke saldo Anda. Penarikan diproses 1-2 menit.",
    },
    {
      title: "Bonus Referral Rp500 / Gmail",
      content:
        "Ajak teman mendaftar menggunakan kode referral Anda. Setiap Gmail teman Anda yang disetujui, Anda mendapat bonus Rp500 otomatis.",
    },
    {
      title: "Penting: Gunakan Gmail Aktif",
      content:
        "Pastikan akun Gmail yang disetorkan aktif dan bisa dibuka. Gmail yang tidak valid akan ditolak oleh tim admin.",
    },
  ]);

  return NextResponse.json({ seeded: true });
}
