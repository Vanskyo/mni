import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  hashPassword,
  makeSalt,
  createSession,
} from "@/lib/auth";
import { generateReferralCode } from "@/lib/utils";
import { getSettings } from "@/lib/settings";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    const ref = String(body.referralCode ?? "").trim().toUpperCase();

    if (!name || name.length < 3) {
      return NextResponse.json(
        { error: "Nama minimal 3 karakter" },
        { status: 400 }
      );
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json(
        { error: "Format email tidak valid" },
        { status: 400 }
      );
    }
    if (password.length < 6) {
      return NextResponse.json(
        { error: "Password minimal 6 karakter" },
        { status: 400 }
      );
    }

    const existing = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);
    if (existing[0]) {
      return NextResponse.json(
        { error: "Email sudah terdaftar, silakan login" },
        { status: 409 }
      );
    }

    let referredBy: string | null = null;
    if (ref) {
      const refResult = await db
        .select()
        .from(users)
        .where(eq(users.referralCode, ref))
        .limit(1);
      if (!refResult[0]) {
        return NextResponse.json(
          { error: "Kode referral tidak valid" },
          { status: 400 }
        );
      }
      referredBy = ref;
    }

    const salt = makeSalt();
    let referralCode = generateReferralCode();
    const codeCheck = await db
      .select()
      .from(users)
      .where(eq(users.referralCode, referralCode))
      .limit(1);
    if (codeCheck[0]) {
      referralCode = generateReferralCode() + Date.now().toString(36).slice(-2).toUpperCase();
    }

    const settings = await getSettings();

    const result = await db
      .insert(users)
      .values({
        name,
        email,
        password: hashPassword(password, salt),
        salt,
        referralCode,
        referredBy,
        balance: settings.referralBonus > 0 && referredBy ? 0 : 0,
        role: "user",
      })
      .returning();

    const user = result[0];
    await createSession(user.id, user.role);

    return NextResponse.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        balance: user.balance,
        role: user.role,
        referralCode: user.referralCode,
      },
    });
  } catch {
    return NextResponse.json(
      { error: "Terjadi kesalahan server" },
      { status: 500 }
    );
  }
}
