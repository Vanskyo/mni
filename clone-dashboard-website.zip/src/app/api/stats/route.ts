import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, gmailSubmissions, withdrawals, settings } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getSettings } from "@/lib/settings";

export async function GET() {
  const [userCount, gmailCount, approvedCount, paidOut] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(users),
    db.select({ count: sql<number>`count(*)` }).from(gmailSubmissions),
    db
      .select({ count: sql<number>`count(*)` })
      .from(gmailSubmissions)
      .where(eq(gmailSubmissions.status, "APPROVED")),
    db
      .select({ sum: sql<number>`coalesce(sum(amount), 0)` })
      .from(withdrawals)
      .where(eq(withdrawals.status, "APPROVED")),
  ]);

  const appSettings = await getSettings();

  return NextResponse.json({
    members: Number(userCount[0]?.count ?? 0),
    totalGmail: Number(gmailCount[0]?.count ?? 0),
    approvedGmail: Number(approvedCount[0]?.count ?? 0),
    paidOut: Number(paidOut[0]?.sum ?? 0),
    pricePerGmail: appSettings.pricePerGmail,
  });
}
