const IDR_MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
  "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
];

export function formatIDR(n: number): string {
  return "Rp" + Math.round(n).toLocaleString("id-ID");
}

export function formatNumber(n: number): string {
  return n.toLocaleString("id-ID");
}

export function formatDate(iso: string | Date): string {
  const d = new Date(iso);
  return `${d.getDate()} ${IDR_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function formatDateTime(iso: string | Date): string {
  const d = new Date(iso);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${d.getDate()} ${IDR_MONTHS[d.getMonth()]} ${d.getFullYear()}, ${hh}:${mm}`;
}

export function timeAgo(iso: string | Date): string {
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "baru saja";
  if (m < 60) return `${m} mnt lalu`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} jam lalu`;
  const days = Math.floor(h / 24);
  if (days < 30) return `${days} hari lalu`;
  return formatDate(d);
}

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateReferralCode(): string {
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
  }
  return code;
}

const FIRST = [
  "budi", "siti", "andi", "rani", "dewi", "agus", "maya", "tono",
  "rina", "fajar", "nina", "bima", "sara", "rio", "lala", "dimas",
  "putri", "arif", "nadia", "yudi", "salsa", "ivan", "dina", "rudi",
];
const LAST = [
  "santoso", "wijaya", "pratama", "sari", "putri", "mulyadi",
  "kurnia", "setiawan", "puspita", "ramadhan", "fitriani", "gunawan",
];

export function randomGmailAddress(): string {
  const f = FIRST[Math.floor(Math.random() * FIRST.length)];
  const l = LAST[Math.floor(Math.random() * LAST.length)];
  const sep = Math.random() > 0.5 ? "." : "";
  const num = Math.floor(Math.random() * 900) + 100;
  const variants = [
    `${f}${sep}${l}${num}`,
    `${f}${l}${num}`,
    `${f}.${l}${Math.floor(Math.random() * 90) + 10}`,
    `${f}${num}${l}`,
  ];
  return `${variants[Math.floor(Math.random() * variants.length)]}@gmail.com`;
}

const PW_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#";

export function randomPassword(len = 12): string {
  let pw = "";
  for (let i = 0; i < len; i++) {
    pw += PW_CHARS[Math.floor(Math.random() * PW_CHARS.length)];
  }
  return pw;
}

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}
