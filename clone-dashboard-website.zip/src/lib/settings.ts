import { db } from "@/db";
import { settings } from "@/db/schema";

export interface AppSettings {
  siteName: string;
  pricePerGmail: number;
  minWithdrawal: number;
  referralBonus: number;
  withdrawalFee: number;
  maintenance: boolean;
}

const DEFAULTS: AppSettings = {
  siteName: "S3L GMAIL ZERO99",
  pricePerGmail: 4700,
  minWithdrawal: 25000,
  referralBonus: 500,
  withdrawalFee: 1500,
  maintenance: false,
};

export async function getSettings(): Promise<AppSettings> {
  try {
    const rows = await db.select().from(settings);
    const map: Record<string, string> = {};
    for (const r of rows) map[r.key] = r.value;
    return {
      siteName: map.siteName ?? DEFAULTS.siteName,
      pricePerGmail: Number(map.pricePerGmail ?? DEFAULTS.pricePerGmail),
      minWithdrawal: Number(map.minWithdrawal ?? DEFAULTS.minWithdrawal),
      referralBonus: Number(map.referralBonus ?? DEFAULTS.referralBonus),
      withdrawalFee: Number(map.withdrawalFee ?? DEFAULTS.withdrawalFee),
      maintenance: map.maintenance === "true",
    };
  } catch {
    return DEFAULTS;
  }
}

export async function setSetting(key: string, value: string) {
  await db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value } });
}
