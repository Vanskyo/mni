import {
  pgTable,
  serial,
  integer,
  varchar,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 191 }).notNull().unique(),
  password: varchar("password", { length: 128 }).notNull(),
  salt: varchar("salt", { length: 32 }).notNull(),
  referralCode: varchar("referral_code", { length: 12 }).notNull().unique(),
  referredBy: varchar("referred_by", { length: 12 }),
  balance: integer("balance").notNull().default(0),
  totalEarned: integer("total_earned").notNull().default(0),
  role: varchar("role", { length: 10 }).notNull().default("user"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const gmailSubmissions = pgTable("gmail_submissions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  accountEmail: varchar("account_email", { length: 191 }).notNull(),
  accountPassword: varchar("account_password", { length: 191 }).notNull(),
  recoveryPhone: varchar("recovery_phone", { length: 20 }),
  status: varchar("status", { length: 10 }).notNull().default("PENDING"),
  price: integer("price").notNull(),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  method: varchar("method", { length: 10 }).notNull(),
  accountName: varchar("account_name", { length: 100 }).notNull(),
  accountNumber: varchar("account_number", { length: 30 }).notNull(),
  amount: integer("amount").notNull(),
  fee: integer("fee").notNull().default(0),
  status: varchar("status", { length: 10 }).notNull().default("PENDING"),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  subject: varchar("subject", { length: 150 }).notNull(),
  category: varchar("category", { length: 30 }).notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 10 }).notNull().default("OPEN"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const ticketReplies = pgTable("ticket_replies", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull().references(() => tickets.id),
  adminId: integer("admin_id").notNull().references(() => users.id),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 150 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  key: varchar("key", { length: 50 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type GmailSubmission = typeof gmailSubmissions.$inferSelect;
export type Withdrawal = typeof withdrawals.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type TicketReply = typeof ticketReplies.$inferSelect;
export type Announcement = typeof announcements.$inferSelect;
