"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Send,
  History,
  Gift,
  Wallet,
  Ticket,
  Settings,
  Menu,
  X,
  Users,
  Megaphone,
  Inbox,
  LogOut,
  ShieldCheck,
  Mail,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "./ui";

const USER_NAV = [
  { href: "/dashboard", label: "Beranda", icon: LayoutDashboard },
  { href: "/dashboard/setoran", label: "Setoran Gmail", icon: Send },
  { href: "/dashboard/riwayat", label: "Riwayat", icon: History },
  { href: "/dashboard/referral", label: "Referral", icon: Gift },
  { href: "/dashboard/tarik-saldo", label: "Tarik Saldo", icon: Wallet },
  { href: "/dashboard/ticket", label: "Tiket Bantuan", icon: Ticket },
];

const ADMIN_NAV = [
  { href: "/admin", label: "Beranda", icon: LayoutDashboard },
  { href: "/admin/setoran", label: "Setoran Masuk", icon: Inbox },
  { href: "/admin/penarikan", label: "Penarikan", icon: Wallet },
  { href: "/admin/pengguna", label: "Pengguna", icon: Users },
  { href: "/admin/pengumuman", label: "Pengumuman", icon: Megaphone },
  { href: "/admin/pengaturan", label: "Pengaturan", icon: Settings },
];

export function SidebarContent({
  items,
  user,
  onNavigate,
}: {
  items: typeof USER_NAV;
  user: { name: string; email: string; balance: number; role: string };
  onNavigate?: () => void;
}) {
  const pathname = usePathname();
  return (
    <div className="flex h-full flex-col">
      <Link href={user.role === "admin" ? "/admin" : "/dashboard"} className="flex items-center gap-2.5 px-5 py-6" onClick={onNavigate}>
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-red-600 shadow-lg shadow-rose-500/30">
          <Mail className="h-4.5 w-4.5 text-white" />
        </div>
        <div>
          <p className="font-display text-sm font-bold leading-tight text-white">
            S3L GMAIL
          </p>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-rose-400">
            Zero99
          </p>
        </div>
      </Link>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2">
        {items.map((item) => {
          const active =
            pathname === item.href ||
            (item.href !== "/dashboard" &&
              item.href !== "/admin" &&
              pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "group flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all",
                active
                  ? "bg-gradient-to-r from-rose-500/15 to-transparent text-rose-400 ring-1 ring-rose-500/20"
                  : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-100"
              )}
            >
              <item.icon
                className={cn(
                  "h-4.5 w-4.5 transition-colors",
                  active ? "text-rose-400" : "text-slate-500 group-hover:text-slate-300"
                )}
              />
              {item.label}
              {active && (
                <span className="ml-auto h-1.5 w-1.5 rounded-full bg-rose-400" />
              )}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-slate-800 p-4">
        <div className="flex items-center gap-3 rounded-xl bg-slate-800/50 p-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-slate-700 to-slate-800 font-display text-xs font-bold text-rose-400 uppercase">
            {user.name.slice(0, 2)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-semibold text-slate-200">
              {user.name}
            </p>
            <p className="truncate text-[11px] text-slate-500">{user.email}</p>
          </div>
          <Link
            href="/api/auth/logout"
            className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-700/60 hover:text-red-400"
            title="Keluar"
          >
            <LogOut className="h-4 w-4" />
          </Link>
        </div>
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/60 px-3 py-2">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
          <span className="text-[11px] text-slate-500">
            Saldo:{" "}
            <span className="font-semibold text-emerald-400">
              Rp{user.balance.toLocaleString("id-ID")}
            </span>
          </span>
        </div>
      </div>
    </div>
  );
}

export function DashboardSidebar({
  user,
}: {
  user: { name: string; email: string; balance: number; role: string };
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      {/* Mobile topbar */}
      <div className="sticky top-0 z-40 flex items-center justify-between border-b border-slate-800 bg-slate-950/90 px-4 py-3 backdrop-blur-md lg:hidden">
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-rose-500 to-red-600">
            <Mail className="h-4 w-4 text-white" />
          </div>
          <span className="font-display text-sm font-bold text-white">
            S3L GMAIL <span className="text-rose-400">ZERO99</span>
          </span>
        </Link>
        <button
          onClick={() => setOpen(true)}
          className="rounded-lg border border-slate-700 p-2 text-slate-300 cursor-pointer"
        >
          <Menu className="h-5 w-5" />
        </button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm lg:hidden"
          onClick={() => setOpen(false)}
        >
          <div
            className="h-full w-72 border-r border-slate-800 bg-slate-950"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setOpen(false)}
              className="absolute right-3 top-4 rounded-lg p-2 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
            <SidebarContent
              items={USER_NAV}
              user={user}
              onNavigate={() => setOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 border-r border-slate-800 bg-slate-950 lg:block">
        <SidebarContent items={USER_NAV} user={user} />
      </aside>
    </>
  );
}

export function AdminSidebar({
  user,
}: {
  user: { name: string; email: string; balance: number; role: string };
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <div className="sticky top-0 z-40 flex items-center justify-between border-b border-slate-800 bg-slate-950/90 px-4 py-3 backdrop-blur-md lg:hidden">
        <Link href="/admin" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-rose-500 to-red-600">
            <Mail className="h-4 w-4 text-white" />
          </div>
          <span className="font-display text-sm font-bold text-white">
            ADMIN <span className="text-rose-400">ZERO99</span>
          </span>
        </Link>
        <button
          onClick={() => setOpen(true)}
          className="rounded-lg border border-slate-700 p-2 text-slate-300 cursor-pointer"
        >
          <Menu className="h-5 w-5" />
        </button>
      </div>

      {open && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm lg:hidden"
          onClick={() => setOpen(false)}
        >
          <div
            className="h-full w-72 border-r border-slate-800 bg-slate-950"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setOpen(false)}
              className="absolute right-3 top-4 rounded-lg p-2 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
            <SidebarContent
              items={ADMIN_NAV}
              user={user}
              onNavigate={() => setOpen(false)}
            />
          </div>
        </div>
      )}

      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 border-r border-slate-800 bg-slate-950 lg:block">
        <SidebarContent items={ADMIN_NAV} user={user} />
      </aside>
    </>
  );
}
